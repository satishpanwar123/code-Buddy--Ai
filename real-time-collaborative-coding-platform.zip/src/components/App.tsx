"use client";
import { useEffect, useState } from "react";
import { Code2, Users, Bot, Mic, PenTool, Play, ArrowRight, Plus, LogIn, LogOut, Clock, Sparkles, GraduationCap, Briefcase, Search, X, Check, History, Trophy, Zap, ShieldCheck, Loader2, Copy, User as UserIcon, BookOpen } from "lucide-react";
import { PROBLEMS } from "@/lib/data";
import Workspace from "./Workspace";

type User={id:number;name:string;email:string;role:string;avatarColor:string;createdAt?:string};
const GUEST_COLORS=["#7C6CFF","#38BDF8","#34D399","#F59E0B","#F472B6"];

export default function App(){
  const [view,setView]=useState<"landing"|"auth"|"dashboard"|"workspace"|"profile">("landing");
  const [authMode,setAuthMode]=useState<"login"|"register">("register");
  const [user,setUser]=useState<User|null>(null); const [token,setToken]=useState("");
  const [guestName,setGuestName]=useState(""); const [userKey,setUserKey]=useState("");
  const [activeRoom,setActiveRoom]=useState("");
  const [rooms,setRooms]=useState<any[]>([]); const [stats,setStats]=useState<any>(null); const [aiHistory,setAiHistory]=useState<any[]>([]);
  const [joinCode,setJoinCode]=useState(""); const [toast,setToast]=useState(""); const [search,setSearch]=useState("");
  const [createOpen,setCreateOpen]=useState(false); const [newTitle,setNewTitle]=useState(""); const [newLang,setNewLang]=useState("javascript"); const [newProblem,setNewProblem]=useState("two-sum"); const [busy,setBusy]=useState(false);
  const [form,setForm]=useState({name:"",email:"",password:"",role:"Student"}); const [authErr,setAuthErr]=useState(""); const [pendingRoom,setPendingRoom]=useState("");

  function showToast(m:string){ setToast(m); setTimeout(()=>setToast(""),3200); }
  const displayUser = user || (guestName? {id:0,name:guestName,email:"",role:"Guest",avatarColor:GUEST_COLORS[guestName.length%5]} : null);

  useEffect(()=>{
    let k=localStorage.getItem("cb_key"); if(!k){ k=Math.random().toString(36).slice(2,10); localStorage.setItem("cb_key",k); } setUserKey(k);
    const t=localStorage.getItem("cb_token")||""; setToken(t);
    const u=localStorage.getItem("cb_user"); if(u) try{ setUser(JSON.parse(u)); }catch{}
    const g=localStorage.getItem("cb_guest")||""; setGuestName(g);
    const roomParam=new URLSearchParams(window.location.search).get("room");
    if(roomParam){ setPendingRoom(roomParam.toUpperCase()); }
    loadRooms(); loadStats();
  },[]);

  useEffect(()=>{ if(pendingRoom && (user||guestName)){ enterRoom(pendingRoom); setPendingRoom(""); } },[pendingRoom,user,guestName]); // eslint-disable-line

  async function loadRooms(){ try{ const r=await fetch("/api/rooms"); const d=await r.json(); setRooms(d.rooms||[]); }catch{} }
  async function loadStats(){ try{ const r=await fetch("/api/rooms?stats=1"); setStats(await r.json()); }catch{} }
  async function loadHistory(tk=token){ try{ const r=await fetch("/api/ai",{headers:tk?{Authorization:`Bearer ${tk}`}:{}}); const d=await r.json(); setAiHistory(d.history||[]); }catch{} }

  async function doAuth(e:React.FormEvent){
    e.preventDefault(); setAuthErr(""); setBusy(true);
    const r=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mode:authMode,...form})});
    const d=await r.json(); setBusy(false);
    if(!r.ok){ setAuthErr(d.error||"Auth failed"); return; }
    setUser(d.user); setToken(d.token); localStorage.setItem("cb_token",d.token); localStorage.setItem("cb_user",JSON.stringify(d.user));
    showToast(authMode==="register"?`Welcome to CodeBuddy-AI, ${d.user.name.split(" ")[0]}! 🎉`:`Welcome back, ${d.user.name.split(" ")[0]}!`);
    if(!pendingRoom) setView("dashboard"); loadRooms(); loadHistory(d.token);
  }
  function continueGuest(){ const n=guestName.trim()||`Guest-${Math.floor(1000+Math.random()*9000)}`; setGuestName(n); localStorage.setItem("cb_guest",n); if(!pendingRoom) setView("dashboard"); else enterRoom(pendingRoom, n); }
  function logout(){ setUser(null); setToken(""); localStorage.removeItem("cb_token"); localStorage.removeItem("cb_user"); setView("landing"); showToast("Signed out. See you soon!"); }

  async function createRoom(problemId=newProblem, lang=newLang, title=newTitle){
    if(!displayUser){ setView("auth"); return; }
    setBusy(true);
    const r=await fetch("/api/rooms",{method:"POST",headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify({title:title||undefined,language:lang,problemId,ownerName:displayUser.name})});
    const d=await r.json(); setBusy(false); setCreateOpen(false);
    if(d.room){ enterRoom(d.room.code); loadRooms(); } else showToast("Could not create room — try again");
  }
  function enterRoom(code:string, nameOverride?:string){
    if(!displayUser && !nameOverride){ setPendingRoom(code.toUpperCase()); setView("auth"); return; }
    setActiveRoom(code.toUpperCase()); setView("workspace");
    window.history.pushState({}, "", `?room=${code.toUpperCase()}`);
  }
  function exitRoom(){ setView("dashboard"); window.history.pushState({},"",window.location.pathname); loadRooms(); loadStats(); }

  const filteredRooms=rooms.filter(r=>(r.title+r.code+r.problemTitle).toLowerCase().includes(search.toLowerCase()));

  if(view==="workspace" && displayUser) return <><Workspace roomCode={activeRoom} user={displayUser} userKey={userKey} token={token} onExit={exitRoom}/>{toast&&<Toast msg={toast}/>}</>;

  return <div className="min-h-screen bg-[#070B14] text-slate-100">
    {/* Nav */}
    <nav className="sticky top-0 z-40 bg-[#070B14]/90 backdrop-blur border-b border-[#1A2440]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center gap-3">
        <button onClick={()=>setView("landing")} className="flex items-center gap-2.5"><span className="w-9 h-9 rounded-xl bg-[#7C6CFF] grid place-items-center text-white font-black text-sm">{`</>`}</span><span className="font-extrabold tracking-tight text-lg">CodeBuddy<span className="text-[#A5B4FC]">-AI</span></span></button>
        <div className="hidden md:flex items-center gap-5 ml-6 text-sm text-slate-300">
          <a href="#features" onClick={()=>setView("landing")} className="hover:text-white">Features</a><a href="#how" onClick={()=>setView("landing")} className="hover:text-white">How it Works</a><a href="#problems" onClick={()=>setView("landing")} className="hover:text-white">Interview Problems</a>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {displayUser ? <>
            <button onClick={()=>{setView("dashboard");loadRooms();}} className="hidden sm:block text-sm bg-[#141E35] px-3.5 py-2 rounded-xl">Dashboard</button>
            <button onClick={()=>{setView("profile");loadHistory();loadRooms();}} className="flex items-center gap-2 bg-[#141E35] pl-1.5 pr-3 py-1.5 rounded-full"><span className="w-7 h-7 rounded-full grid place-items-center text-[11px] font-bold text-white" style={{background:displayUser.avatarColor||"#7C6CFF"}}>{displayUser.name.slice(0,2).toUpperCase()}</span><span className="text-sm max-w-[110px] truncate">{displayUser.name}</span></button>
            <button onClick={logout} title="Sign out" className="p-2 text-slate-400 hover:text-white"><LogOut size={17}/></button>
          </> : <>
            <button onClick={()=>{setAuthMode("login");setView("auth");}} className="text-sm px-3.5 py-2 rounded-xl bg-[#141E35]">Sign In</button>
            <button onClick={()=>{setAuthMode("register");setView("auth");}} className="text-sm px-4 py-2 rounded-xl bg-[#7C6CFF] font-semibold">Get Started</button>
          </>}
        </div>
      </div>
    </nav>

    {view==="landing" && <>
      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-14 pb-10 grid lg:grid-cols-2 gap-10 items-center">
        <div className="fadeup">
          <span className="inline-flex items-center gap-2 bg-[#141E35] border border-[#26314D] text-[#A5B4FC] text-xs font-semibold px-3 py-1.5 rounded-full"><span className="w-2 h-2 bg-emerald-400 rounded-full pulsedot"/> REAL-TIME · AI MENTOR · VOICE + WHITEBOARD</span>
          <h1 className="text-[42px] sm:text-[58px] leading-[1.02] font-extrabold tracking-tight mt-5">Code Together.<br/><span className="text-[#8B7CFF]">Learn Faster.</span></h1>
          <p className="text-slate-400 text-lg leading-relaxed mt-5 max-w-lg">One workspace where students, developers, mentors and interviewers write code together in real time — with an AI tutor that explains, debugs and asks the follow-up questions a real interviewer would.</p>
          <div className="flex flex-wrap gap-3 mt-7">
            <button onClick={()=> displayUser? setCreateOpen(true): setView("auth")} className="flex items-center gap-2 bg-[#7C6CFF] hover:bg-[#6B5CF0] font-bold px-6 py-3.5 rounded-2xl">Get Started <ArrowRight size={17}/></button>
            <a href="#features" className="flex items-center gap-2 bg-[#141E35] border border-[#26314D] font-semibold px-6 py-3.5 rounded-2xl">Explore Features</a>
          </div>
          <div className="flex gap-2 mt-4">
            <input value={joinCode} onChange={e=>setJoinCode(e.target.value.toUpperCase())} placeholder="Have a room code? e.g. K7X2PQ" className="bg-[#0D1424] border border-[#26314D] rounded-xl px-4 py-3 text-sm font-mono outline-none w-60"/>
            <button onClick={()=>joinCode.trim()&&enterRoom(joinCode.trim())} className="bg-[#0F2A22] text-emerald-300 border border-emerald-900 font-semibold px-4 rounded-xl text-sm">Join Room →</button>
          </div>
          <div className="grid grid-cols-3 gap-3 mt-9 max-w-md">
            {[["Rooms created", stats? String(stats.rooms):"…"],["AI mentor sessions", stats? String(stats.aiSessions):"…"],["Code executions", stats? String(stats.executions):"…"]].map(([k,v])=><div key={k} className="bg-[#0D1424] border border-[#1E2A47] rounded-2xl p-3.5"><p className="text-2xl font-extrabold">{v}</p><p className="text-[11px] text-slate-500">{k} (live)</p></div>)}
          </div>
          <p className="text-xs text-slate-500 mt-4">No credit card · Try the demo: create a room, open the invite link in an incognito window, and type in both.</p>
        </div>
        {/* Mock IDE */}
        <div className="fadeup bg-[#0B1120] border border-[#26314D] rounded-3xl overflow-hidden shadow-2xl">
          <div className="flex items-center gap-2 px-4 py-3 bg-[#0D1424] border-b border-[#1E2A47] text-xs"><span className="w-3 h-3 rounded-full bg-rose-500"/><span className="w-3 h-3 rounded-full bg-amber-400"/><span className="w-3 h-3 rounded-full bg-emerald-400"/><span className="ml-2 text-slate-400 font-mono">two-sum.js — Room K7X2PQ</span><span className="ml-auto flex -space-x-1.5">{["#7C6CFF","#38BDF8","#34D399"].map(c=><span key={c} className="w-6 h-6 rounded-full border-2 border-[#0D1424]" style={{background:c}}/>)}</span></div>
          <div className="grid sm:grid-cols-[1.5fr_1fr]">
            <pre className="p-4 text-[12.5px] leading-6 font-mono text-slate-300 overflow-x-auto">{`function twoSum(nums, target) {
  const seen = new Map();
  for (let i = 0; i < nums.length; i++) {
    const need = target - nums[i];`}<span className="bg-[#7C6CFF]/30 rounded px-0.5">{`
    if (seen.has(need))`}</span>{`
      return [seen.get(need), i];
    seen.set(nums[i], i);
  }
}`}
              <span className="block mt-2 text-emerald-300">▶ [0, 1] · 42 ms ✓</span></pre>
            <div className="border-t sm:border-t-0 sm:border-l border-[#1E2A47] p-4 space-y-3 text-xs">
              <p className="flex items-center gap-1.5 font-bold text-sm"><Bot size={15} className="text-[#A5B4FC]"/> AI Mentor</p>
              <div className="bg-[#141E35] rounded-xl p-3 leading-relaxed"><b>Hint 1 of 3:</b> For each number x, you need <code className="bg-[#1B2540] px-1 rounded">target − x</code>. Have you seen it before?</div>
              <div className="bg-[#141E35] rounded-xl p-3 leading-relaxed">Complexity: <b className="text-emerald-300">O(n) time</b> — one pass, O(1) lookups. Interview-ready ✓</div>
              <div className="flex gap-1.5 flex-wrap">{["Explain","Find Bugs","Test Cases"].map(x=><span key={x} className="bg-[#1B2540] px-2 py-1 rounded-full">{x}</span>)}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <h2 className="text-3xl font-extrabold text-center">Everything a coding session needs</h2><p className="text-slate-400 text-center mt-2">Built for DSA practice, remote pair programming, mentoring and technical interviews.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-9">
          {[
            {icon:Code2,color:"#7C6CFF",t:"Collaborative Editing",d:"Monaco-powered editor with live sync, shared cursors, presence and version-safe updates across sessions."},
            {icon:Bot,color:"#38BDF8",t:"AI Mentoring",d:"Line-by-line explanations, bug hunts, generated test cases, complexity analysis and progressive hints — never just the answer."},
            {icon:Mic,color:"#34D399",t:"Voice Chat",d:"Join with one tap, see who's speaking, mute anytime. Talk through the algorithm like a real interview."},
            {icon:PenTool,color:"#F59E0B",t:"Shared Whiteboard",d:"Sketch recursion trees, DP tables and pointer moves together with shapes, arrows and text — synced live."},
            {icon:Play,color:"#F472B6",t:"Sandboxed Execution",d:"Run JavaScript, Python, C++, Java & TypeScript in an isolated sandbox. Code never executes on the app server."},
            {icon:GraduationCap,color:"#22D3EE",t:"Interview Practice",d:"Curated problems with AI playing interviewer — follow-ups, trade-offs and walkthrough narration."},
            {icon:Users,color:"#A78BFA",t:"Rooms & Invites",d:"Create a room in one click, share a 6-character code or link. Guests can join without an account."},
            {icon:ShieldCheck,color:"#34D399",t:"Secure by Design",d:"bcrypt-hashed passwords, signed tokens, protected APIs, input limits and server-side AI handling."},
          ].map(f=>{ const Icon=f.icon; return <div key={f.t} className="bg-[#0D1424] border border-[#1E2A47] rounded-3xl p-5 hover:border-[#35466E] transition"><span className="w-11 h-11 rounded-2xl grid place-items-center" style={{background:f.color+"22"}}><Icon size={21} style={{color:f.color}}/></span><h3 className="font-bold mt-3.5">{f.t}</h3><p className="text-[13px] text-slate-400 leading-relaxed mt-1.5">{f.d}</p></div>})}
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="bg-[#0D1424] border border-[#1E2A47] rounded-[28px] p-6 sm:p-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold">How It Works</h2>
          <div className="grid md:grid-cols-4 gap-6 mt-7">
            {[["1","Create a room","Pick a language and an interview problem — or start a freestyle playground."],["2","Invite your buddy","Share the room code or link. They join instantly, even as a guest."],["3","Code, talk, draw","Edit together in Monaco, discuss over voice, sketch on the whiteboard, run in the sandbox."],["4","Learn with AI","Get hints, explanations, reviews and test cases. Save the session to your history."]].map(([n,t,d])=><div key={n}><span className="w-10 h-10 rounded-full bg-[#7C6CFF] grid place-items-center font-extrabold">{n}</span><h3 className="font-bold mt-3">{t}</h3><p className="text-sm text-slate-400 leading-relaxed mt-1">{d}</p></div>)}
          </div>
          <div className="flex flex-wrap gap-2 mt-8 text-xs">{["👩‍🎓 Students practising DSA","🧑‍💻 Remote developers","🧑‍🏫 Coding mentors","🎙️ Interviewers","👥 Dev teams"].map(x=><span key={x} className="bg-[#141E35] border border-[#26314D] px-3 py-1.5 rounded-full">{x}</span>)}</div>
        </div>
      </section>

      {/* Problems */}
      <section id="problems" className="max-w-7xl mx-auto px-4 sm:px-6 py-10 pb-16">
        <div className="flex items-end justify-between flex-wrap gap-3"><div><h2 className="text-3xl font-extrabold">Interview Problem Library</h2><p className="text-slate-400 mt-1.5">Launch any problem straight into a collaborative room.</p></div></div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-7">
          {PROBLEMS.map(p=><div key={p.id} className="bg-[#0D1424] border border-[#1E2A47] rounded-3xl p-5 flex flex-col">
            <div className="flex items-center gap-2"><h3 className="font-bold">{p.title}</h3><span className={`ml-auto text-[11px] px-2 py-0.5 rounded-full font-semibold ${p.difficulty==="Easy"?"bg-emerald-500/15 text-emerald-300":p.difficulty==="Medium"?"bg-amber-500/15 text-amber-300":p.difficulty==="Open"?"bg-sky-500/15 text-sky-300":"bg-rose-500/15 text-rose-300"}`}>{p.difficulty}</span></div>
            <p className="text-[11px] text-slate-500">{p.company}</p>
            <p className="text-[13px] text-slate-400 leading-relaxed mt-2 flex-1 line-clamp-3">{p.description}</p>
            <div className="flex gap-1 mt-3 flex-wrap">{p.tags.map(t=><span key={t} className="text-[11px] bg-[#141E35] px-2 py-0.5 rounded-full">{t}</span>)}</div>
            <button onClick={()=>{ if(!displayUser){ setNewProblem(p.id); setView("auth"); showToast("Sign in or continue as guest to start this room"); } else createRoom(p.id,"javascript",""); }} className="mt-4 bg-[#141E35] hover:bg-[#7C6CFF] transition font-semibold text-sm py-2.5 rounded-xl">Start collaborative room →</button>
          </div>)}
        </div>
      </section>
      <Footer/>
    </>}

    {view==="auth" && <section className="max-w-md mx-auto px-4 py-12">
      <div className="bg-[#0D1424] border border-[#26314D] rounded-[24px] p-7 fadeup">
        <span className="w-11 h-11 rounded-2xl bg-[#7C6CFF] grid place-items-center font-black">{`</>`}</span>
        <h1 className="text-2xl font-extrabold mt-4">{authMode==="register"?"Create your account":"Welcome back"}</h1>
        <p className="text-slate-400 text-sm mt-1">{pendingRoom?`You're joining room ${pendingRoom} — sign in or continue as guest.`:"Save rooms, track AI sessions and build your interview streak."}</p>
        <div className="grid grid-cols-2 bg-[#0A101F] rounded-xl p-1 mt-5 text-sm font-semibold">
          <button onClick={()=>setAuthMode("register")} className={`py-2 rounded-lg ${authMode==="register"?"bg-[#7C6CFF]":"text-slate-400"}`}>Register</button>
          <button onClick={()=>setAuthMode("login")} className={`py-2 rounded-lg ${authMode==="login"?"bg-[#7C6CFF]":"text-slate-400"}`}>Login</button>
        </div>
        <form onSubmit={doAuth} className="space-y-3 mt-5">
          {authMode==="register" && <>
            <input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Full name" className="w-full bg-[#0A101F] border border-[#26314D] rounded-xl px-4 py-3 text-sm outline-none"/>
            <select value={form.role} onChange={e=>setForm({...form,role:e.target.value})} className="w-full bg-[#0A101F] border border-[#26314D] rounded-xl px-4 py-3 text-sm outline-none">{["Student","Developer","Mentor / Teacher","Interviewer","Team Lead"].map(r=><option key={r}>{r}</option>)}</select>
          </>}
          <input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="Email address" className="w-full bg-[#0A101F] border border-[#26314D] rounded-xl px-4 py-3 text-sm outline-none"/>
          <input required type="password" minLength={6} value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="Password (min 6 characters)" className="w-full bg-[#0A101F] border border-[#26314D] rounded-xl px-4 py-3 text-sm outline-none"/>
          {authErr && <p className="text-rose-300 bg-rose-500/10 border border-rose-500/30 text-[13px] rounded-xl px-3 py-2.5">{authErr}</p>}
          <button disabled={busy} className="w-full bg-[#7C6CFF] hover:bg-[#6B5CF0] font-bold py-3.5 rounded-xl disabled:opacity-60">{busy?<Loader2 className="animate-spin mx-auto" size={18}/>: authMode==="register"?"Create account →":"Sign in →"}</button>
        </form>
        <div className="flex items-center gap-3 my-5 text-[11px] text-slate-500"><span className="flex-1 border-t border-[#26314D]"/>OR CONTINUE AS GUEST<span className="flex-1 border-t border-[#26314D]"/></div>
        <div className="flex gap-2"><input value={guestName} onChange={e=>setGuestName(e.target.value)} placeholder="Display name (e.g. Alex)" className="flex-1 bg-[#0A101F] border border-[#26314D] rounded-xl px-4 py-3 text-sm outline-none"/><button onClick={continueGuest} className="bg-[#141E35] border border-[#26314D] px-4 rounded-xl text-sm font-semibold">Join →</button></div>
        <p className="text-[11px] text-slate-500 mt-4 flex items-center gap-1.5"><ShieldCheck size={13}/> Passwords are bcrypt-hashed; sessions use signed tokens. Demo hint: register any email to try it instantly.</p>
      </div>
    </section>}

    {view==="dashboard" && <section className="max-w-7xl mx-auto px-4 sm:px-6 py-9">
      <div className="flex flex-wrap items-center gap-4">
        <div><h1 className="text-[28px] font-extrabold">Welcome{displayUser?`, ${displayUser.name.split(" ")[0]}`:""} 👋</h1><p className="text-slate-400 text-sm mt-1">{displayUser?.role} · Ready for your next session? Create a room, or jump back into a recent one.</p></div>
        <div className="ml-auto flex flex-wrap gap-2">
          <div className="flex"><input value={joinCode} onChange={e=>setJoinCode(e.target.value.toUpperCase())} placeholder="Room code" className="bg-[#0D1424] border border-[#26314D] rounded-l-xl px-3.5 py-2.5 text-sm font-mono outline-none w-32"/><button onClick={()=>joinCode.trim()?enterRoom(joinCode.trim()):showToast("Enter a room code first")} className="bg-[#141E35] border border-l-0 border-[#26314D] px-4 rounded-r-xl text-sm font-semibold flex items-center gap-1.5"><LogIn size={15}/> Join</button></div>
          <button onClick={()=>setCreateOpen(true)} className="flex items-center gap-2 bg-[#7C6CFF] font-bold px-5 py-2.5 rounded-xl text-sm"><Plus size={17}/> Create New Coding Room</button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-7">
        {[{icon:Code2,v:String(rooms.length),l:"Total rooms"},{icon:Users,v:String(rooms.reduce((a,r)=>a+(r.liveCount||0),0)),l:"Coders online now"},{icon:Bot,v:stats?String(stats.aiSessions):"…",l:"AI mentor answers"},{icon:Zap,v:stats?String(stats.executions):"…",l:"Sandbox runs"}].map(s=>{ const Icon=s.icon; return <div key={s.l} className="bg-[#0D1424] border border-[#1E2A47] rounded-2xl p-4 flex items-center gap-3"><span className="w-10 h-10 rounded-xl bg-[#7C6CFF]/15 grid place-items-center text-[#A5B4FC]"><Icon size={19}/></span><div><p className="text-xl font-extrabold leading-none">{s.v}</p><p className="text-[11px] text-slate-500 mt-1">{s.l}</p></div></div>})}
      </div>

      <div className="flex items-center gap-3 mt-9">
        <h2 className="text-lg font-bold flex items-center gap-2"><Clock size={18}/> Recent Coding Sessions</h2>
        <div className="ml-auto relative"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search rooms…" className="bg-[#0D1424] border border-[#26314D] rounded-xl pl-9 pr-3 py-2.5 text-sm outline-none w-52"/></div>
      </div>
      {filteredRooms.length===0 ? <div className="bg-[#0D1424] border border-dashed border-[#35466E] rounded-3xl p-10 text-center mt-4">
        <p className="text-5xl">🛋️</p><h3 className="font-bold text-lg mt-3">{rooms.length===0?"No coding rooms yet — be the first!":"No rooms match your search"}</h3>
        <p className="text-slate-400 text-sm mt-1.5 max-w-sm mx-auto">Create a room, invite a buddy with the code, and your sessions will show up here for quick re-entry.</p>
        <button onClick={()=>setCreateOpen(true)} className="mt-5 bg-[#7C6CFF] font-bold px-5 py-3 rounded-xl text-sm">+ Create your first room</button>
      </div> : <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
        {filteredRooms.map(r=><div key={r.id} className="bg-[#0D1424] border border-[#1E2A47] rounded-3xl p-5 hover:border-[#35466E] transition">
          <div className="flex items-start gap-2"><div className="flex-1 min-w-0"><h3 className="font-bold truncate">{r.title}</h3><p className="text-[12px] text-slate-500">{r.problemTitle} · {r.language} · by {r.ownerName}</p></div>{r.liveCount>0&&<span className="text-[11px] bg-emerald-500/15 text-emerald-300 px-2 py-1 rounded-full font-semibold flex items-center gap-1"><span className="w-1.5 h-1.5 bg-emerald-400 rounded-full pulsedot"/>{r.liveCount} live</span>}</div>
          <div className="flex items-center gap-2 mt-4"><span className="font-mono tracking-[.2em] bg-[#141E35] px-2.5 py-1.5 rounded-lg text-[#A5B4FC] text-sm font-bold">{r.code}</span><button onClick={()=>{navigator.clipboard?.writeText(`${window.location.origin}${window.location.pathname}?room=${r.code}`);showToast("Invite link copied!");}} className="p-2 bg-[#141E35] rounded-lg" title="Copy invite link"><Copy size={15}/></button><span className="text-[11px] text-slate-500 ml-auto">{new Date(r.updatedAt).toLocaleDateString()} {new Date(r.updatedAt).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</span></div>
          <button onClick={()=>enterRoom(r.code)} className="w-full mt-4 bg-[#141E35] hover:bg-[#7C6CFF] transition font-semibold text-sm py-2.5 rounded-xl">Rejoin room →</button>
        </div>)}
      </div>}

      <h2 className="text-lg font-bold mt-10 flex items-center gap-2"><BookOpen size={18}/> Quick-start Interview Practice</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-3">
        {PROBLEMS.slice(0,4).map(p=><button key={p.id} onClick={()=>createRoom(p.id,"javascript","")} className="text-left bg-[#0D1424] border border-[#1E2A47] hover:border-[#7C6CFF] rounded-2xl p-4 transition"><p className="font-bold text-sm">{p.title}</p><p className="text-[12px] text-slate-400 mt-1">{p.difficulty} · {p.tags.join(" · ")}</p><p className="text-[12px] text-[#A5B4FC] font-semibold mt-2">▶ Start room</p></button>)}
      </div>
    </section>}

    {view==="profile" && <section className="max-w-5xl mx-auto px-4 sm:px-6 py-9">
      <div className="bg-[#0D1424] border border-[#26314D] rounded-[24px] p-6 flex flex-wrap items-center gap-4">
        <span className="w-20 h-20 rounded-3xl grid place-items-center text-2xl font-extrabold text-white" style={{background:displayUser?.avatarColor||"#7C6CFF"}}>{displayUser?.name.slice(0,2).toUpperCase()}</span>
        <div className="flex-1"><h1 className="text-2xl font-extrabold">{displayUser?.name}</h1><p className="text-slate-400 text-sm">{displayUser?.email||"Guest account — register to persist everything"} · {displayUser?.role}</p>
        <div className="flex gap-2 mt-3 text-xs"><span className="bg-[#141E35] px-3 py-1.5 rounded-full">🏆 {rooms.filter(r=>r.ownerName===displayUser?.name).length} rooms hosted</span><span className="bg-[#141E35] px-3 py-1.5 rounded-full">🤖 {aiHistory.length} AI interactions</span><span className="bg-[#141E35] px-3 py-1.5 rounded-full">⚡ Joined {displayUser?.createdAt?new Date(displayUser.createdAt).toLocaleDateString():"today"}</span></div></div>
        <button onClick={logout} className="bg-[#2A1530] text-rose-300 px-4 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-2"><LogOut size={15}/> Sign out</button>
      </div>

      <h2 className="text-lg font-bold mt-9 flex items-center gap-2"><History size={18}/> Saved Sessions & Recent Rooms</h2>
      <div className="grid sm:grid-cols-2 gap-3 mt-3">
        {rooms.slice(0,6).map(r=><button key={r.id} onClick={()=>enterRoom(r.code)} className="text-left bg-[#0D1424] border border-[#1E2A47] rounded-2xl p-4 hover:border-[#35466E]"><p className="font-bold text-sm truncate">{r.title}</p><p className="text-[12px] text-slate-500 mt-1">{r.problemTitle} · {r.language} · code <span className="font-mono text-[#A5B4FC]">{r.code}</span> · {new Date(r.updatedAt).toLocaleDateString()}</p></button>)}
        {rooms.length===0&&<p className="text-slate-500 text-sm">No sessions yet — create a room from the dashboard.</p>}
      </div>

      <h2 className="text-lg font-bold mt-9 flex items-center gap-2"><Bot size={18}/> AI Mentoring Conversations</h2>
      <div className="space-y-3 mt-3">
        {aiHistory.slice(0,8).map((a:any)=><div key={a.id} className="bg-[#0D1424] border border-[#1E2A47] rounded-2xl p-4"><div className="flex items-center gap-2 text-xs"><span className="bg-[#7C6CFF]/20 text-[#C4B5FD] px-2 py-1 rounded-full font-semibold capitalize">{a.action}</span><span className="text-slate-500">{a.language} · {a.roomCode?`room ${a.roomCode} · `:""}{new Date(a.createdAt).toLocaleString()}</span>{a.roomCode&&<button onClick={()=>enterRoom(a.roomCode)} className="ml-auto text-[#A5B4FC] font-semibold">Open room →</button>}</div><p className="text-[13px] text-slate-300 leading-relaxed mt-2.5 whitespace-pre-wrap line-clamp-4">{a.response}</p></div>)}
        {aiHistory.length===0&&<p className="text-slate-500 text-sm">No AI sessions yet — open a room and tap “Explain Code” to start learning.</p>}
      </div>
    </section>}

    {/* Create modal */}
    {createOpen && <div className="fixed inset-0 z-50 bg-black/70 grid place-items-end sm:place-items-center p-0 sm:p-4" onClick={()=>setCreateOpen(false)}>
      <div className="bg-[#0D1424] border border-[#35466E] w-full max-w-lg rounded-t-[24px] sm:rounded-[24px] p-6 max-h-[92vh] overflow-y-auto" onClick={e=>e.stopPropagation()}>
        <div className="flex items-center justify-between"><h2 className="text-xl font-extrabold">Create Coding Room</h2><button onClick={()=>setCreateOpen(false)}><X/></button></div>
        <p className="text-slate-400 text-sm mt-1">You'll get a shareable room code instantly.</p>
        <label className="block text-xs font-bold text-slate-400 mt-5">ROOM TITLE (OPTIONAL)</label>
        <input value={newTitle} onChange={e=>setNewTitle(e.target.value)} placeholder="e.g. Friday DSA Practice with Sam" className="w-full bg-[#0A101F] border border-[#26314D] rounded-xl px-4 py-3 text-sm outline-none mt-1.5"/>
        <label className="block text-xs font-bold text-slate-400 mt-4">LANGUAGE</label>
        <div className="flex flex-wrap gap-2 mt-1.5">{[["javascript","JavaScript"],["python","Python"],["cpp","C++"],["java","Java"],["typescript","TypeScript"]].map(([id,l])=><button key={id} onClick={()=>setNewLang(id)} className={`px-3.5 py-2 rounded-full text-sm font-medium border ${newLang===id?"bg-[#7C6CFF] border-[#7C6CFF]":"bg-[#141E35] border-[#26314D]"}`}>{l}</button>)}</div>
        <label className="block text-xs font-bold text-slate-400 mt-4">PROBLEM / TEMPLATE</label>
        <div className="grid grid-cols-2 gap-2 mt-1.5">{PROBLEMS.map(p=><button key={p.id} onClick={()=>setNewProblem(p.id)} className={`text-left px-3.5 py-3 rounded-xl border text-sm ${newProblem===p.id?"bg-[#241E4E] border-[#7C6CFF]":"bg-[#141E35] border-[#26314D]"}`}><span className="font-semibold block">{p.title}</span><span className="text-[11px] text-slate-400">{p.difficulty} · {p.tags[0]}</span></button>)}</div>
        <button disabled={busy} onClick={()=>createRoom()} className="w-full bg-[#7C6CFF] hover:bg-[#6B5CF0] font-bold py-3.5 rounded-xl mt-6 disabled:opacity-60">{busy?"Creating…":"🚀 Create Room & Start Coding"}</button>
      </div>
    </div>}
    {toast&&<Toast msg={toast}/>}
  </div>;
}
function Toast({msg}:{msg:string}){ return <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[60] bg-[#141E35] border border-[#35466E] text-sm font-medium px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-2 fadeup"><Check size={16} className="text-emerald-400"/>{msg}</div>; }
function Footer(){ return <footer className="border-t border-[#1A2440] mt-4"><div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 grid sm:grid-cols-4 gap-6 text-sm">
  <div><p className="font-extrabold text-base">CodeBuddy<span className="text-[#A5B4FC]">-AI</span></p><p className="text-slate-500 text-[13px] mt-2 leading-relaxed">Real-time collaborative coding with an AI mentor, voice and whiteboard. Code Together. Learn Faster.</p></div>
  <div><p className="font-bold">Product</p><ul className="text-slate-400 space-y-1.5 mt-2.5"><li>Collaborative Editor</li><li>AI Mentor</li><li>Voice Chat</li><li>Whiteboard</li></ul></div>
  <div><p className="font-bold">Use Cases</p><ul className="text-slate-400 space-y-1.5 mt-2.5"><li>DSA Practice</li><li>Technical Interviews</li><li>Mentoring & Teaching</li><li>Pair Programming</li></ul></div>
  <div><p className="font-bold">Stack</p><ul className="text-slate-400 space-y-1.5 mt-2.5"><li>Next.js · TypeScript · Monaco</li><li>PostgreSQL (Drizzle) — live sync</li><li>Sandboxed execution (Piston)</li><li>WebRTC mic · JWT auth (bcrypt)</li></ul></div>
  <p className="sm:col-span-4 text-[12px] text-slate-600 border-t border-[#141E35] pt-4">© 2026 CodeBuddy-AI. AI suggestions are educational guidance — always verify with test cases. Submitted code only ever runs in an isolated sandbox.</p>
</div></footer>; }
