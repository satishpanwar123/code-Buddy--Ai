"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import dynamic from "next/dynamic";
import { Play, Save, Copy, Check, Users, Bot, Mic, MicOff, Phone, PhoneOff, Send, Lightbulb, Bug, FileSearch, ListChecks, Gauge, GraduationCap, MessageSquare, ArrowLeft, Wifi, WifiOff, Loader2, Download, ChevronDown, Sparkles, Terminal, X, Volume2 } from "lucide-react";
import { PROBLEMS, LANGS, starterFor } from "@/lib/data";
import Whiteboard from "./Whiteboard";

const Monaco = dynamic(()=>import("@monaco-editor/react").then(m=>m.default), { ssr:false, loading:()=><div className="h-full grid place-items-center text-slate-400 text-sm">Loading Monaco editor…</div> });

type User={id?:number;name:string;email?:string;avatarColor?:string;role?:string};
function md(t:string){ return t.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/`([^`]+)`/g,"<code>$1</code>").replace(/^> (.+)$/gm,'<span style="color:#94A3B8;font-style:italic">$1</span>'); }

export default function Workspace({ roomCode, user, userKey, token, onExit }: { roomCode:string; user:User; userKey:string; token:string; onExit:()=>void }){
  const [room,setRoom]=useState<any>(null); const [err,setErr]=useState("");
  const [code,setCode]=useState(""); const [lang,setLang]=useState("javascript");
  const [participants,setParticipants]=useState<any[]>([]); const [messages,setMessages]=useState<any[]>([]);
  const [tab,setTab]=useState<"code"|"board">("code"); const [side,setSide]=useState<"ai"|"chat"|"people"|"voice">("ai");
  const [consoleOpen,setConsoleOpen]=useState(true); const [stdin,setStdin]=useState(""); const [output,setOutput]=useState(""); const [runErr,setRunErr]=useState(""); const [running,setRunning]=useState(false); const [runMs,setRunMs]=useState(0);
  const [aiChat,setAiChat]=useState<{role:string;text:string}[]>([{role:"ai",text:"**Hi! I'm your AI Mentor.** Select code and hit *Explain*, ask for a hint (I start small — no spoilers), or let me hunt bugs and generate edge cases for you."}]);
  const [aiInput,setAiInput]=useState(""); const [aiBusy,setAiBusy]=useState(""); const [hintLevel,setHintLevel]=useState(0);
  const [chatInput,setChatInput]=useState(""); const [copied,setCopied]=useState(""); const [saved,setSaved]=useState(false);
  const [connected,setConnected]=useState(true); const [cursorLine,setCursorLine]=useState(1);
  const [selectedText,setSelectedText]=useState("");
  // voice
  const [inVoice,setInVoice]=useState(false); const [micOn,setMicOn]=useState(true); const [speaking,setSpeaking]=useState(false); const [voiceErr,setVoiceErr]=useState(""); const [level,setLevel]=useState(0);
  const streamRef=useRef<MediaStream|null>(null); const rafRef=useRef<number>(0);
  const editorRef=useRef<any>(null); const codeRef=useRef(code); codeRef.current=code;
  const versionRef=useRef(0); const lastTypeRef=useRef(0); const aiEndRef=useRef<HTMLDivElement>(null); const chatEndRef=useRef<HTMLDivElement>(null);
  const stateRef=useRef({micOn,speaking,inVoice,cursorLine}); stateRef.current={micOn,speaking,inVoice,cursorLine};
  const color=user.avatarColor||"#7C6CFF";
  const problem=PROBLEMS.find(p=>p.id===room?.problemId)||PROBLEMS[0];

  const authHeaders = token?{Authorization:`Bearer ${token}`} : {} as Record<string,string>;

  const fetchRoom=useCallback(async()=>{
    try{
      const r=await fetch(`/api/rooms/${roomCode}`); if(!r.ok) throw new Error((await r.json()).error||"Room not found");
      const d=await r.json(); setConnected(true);
      setParticipants(d.participants); setMessages(d.messages);
      if(!room){ setRoom(d.room); setCode(d.room.codeContent); setLang(d.room.language); versionRef.current=d.room.version; }
      else{
        // Remote sync: accept if version newer, someone else edited, and I haven't typed in 1.2s
        if(d.room.version>versionRef.current && d.room.lastEditor!==user.name && Date.now()-lastTypeRef.current>1200 && d.room.codeContent!==codeRef.current){
          setCode(d.room.codeContent);
        }
        if(d.room.version>versionRef.current) versionRef.current=d.room.version;
        setRoom((prev:any)=>({...prev, whiteboard:d.room.whiteboard, version:d.room.version, lastEditor:d.room.lastEditor, title:d.room.title}));
      }
    }catch(e:any){ setConnected(false); if(!room) setErr(e.message); }
  },[roomCode, room, user.name]);

  useEffect(()=>{ fetchRoom(); /* eslint-disable-next-line */ },[]);
  useEffect(()=>{ const id=setInterval(fetchRoom, 2200); return ()=>clearInterval(id); },[fetchRoom]);
  useEffect(()=>{ aiEndRef.current?.scrollIntoView({behavior:"smooth"}); },[aiChat]);
  useEffect(()=>{ chatEndRef.current?.scrollIntoView({behavior:"smooth"}); },[messages]);

  // heartbeat presence
  useEffect(()=>{
    const beat=async()=>{ const s=stateRef.current; await fetch(`/api/rooms/${roomCode}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"heartbeat",userKey,name:user.name,color,cursorLine:s.cursorLine,micOn:s.inVoice&&s.micOn,speaking:s.speaking,inVoice:s.inVoice})}).catch(()=>{}); };
    beat(); const id=setInterval(beat,4000); return ()=>clearInterval(id);
  },[roomCode,userKey,user.name,color]);

  // debounced code sync (CRDT-style last-writer with versioning + cursor preserved by Monaco)
  useEffect(()=>{
    if(!room || code===room.codeContent) return;
    const id=setTimeout(async()=>{
      const r=await fetch(`/api/rooms/${roomCode}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({codeContent:code,editor:user.name})});
      if(r.ok){ const d=await r.json(); versionRef.current=d.room.version; setSaved(true); setTimeout(()=>setSaved(false),1500); }
    },800);
    return ()=>clearTimeout(id);
  },[code]); // eslint-disable-line

  async function runCode(){
    setRunning(true); setOutput(""); setRunErr(""); setConsoleOpen(true);
    try{
      const r=await fetch("/api/execute",{method:"POST",headers:{"Content-Type":"application/json",...authHeaders},body:JSON.stringify({language:lang,code,stdin,roomCode})});
      const d=await r.json(); setRunMs(d.runtimeMs||0);
      if(d.fallback && lang==="javascript"){
        // In-browser fallback sandbox
        const logs:string[]=[]; const fake={log:(...a:any[])=>logs.push(a.map(x=>typeof x==="object"?JSON.stringify(x):String(x)).join(" ")),error:(...a:any[])=>logs.push("Error: "+a.join(" "))};
        try{ new Function("console", code)(fake); setOutput(logs.join("\n")||"(no output — add console.log)"); }catch(e:any){ setRunErr(String(e)); }
      } else { setOutput(d.stdout||""); setRunErr(d.stderr||d.error||""); if(!d.stdout && !d.stderr) setOutput("(program finished with no output)"); }
    }catch(e:any){ setRunErr("Execution failed: "+e.message); }
    setRunning(false);
  }

  async function askAI(action:string, prompt?:string){
    if(aiBusy) return; setSide("ai");
    const label=prompt||action; setAiBusy(action);
    if(action==="chat"&&prompt) setAiChat(c=>[...c,{role:"user",text:prompt}]);
    try{
      const r=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json",...authHeaders},body:JSON.stringify({action,code,language:lang,problemId:room?.problemId,prompt:prompt||"",hintLevel,selected:selectedText,roomCode})});
      const d=await r.json(); if(!r.ok) throw new Error(d.error||"AI error");
      setAiChat(c=>[...c,{role:"ai",text:d.response}]);
      if(action==="hint") setHintLevel(h=>Math.min(h+1,2));
    }catch(e:any){ setAiChat(c=>[...c,{role:"ai",text:"⚠️ "+e.message+" — try again in a moment."}]); }
    setAiBusy("");
  }

  async function sendChat(){
    if(!chatInput.trim()) return; const body=chatInput; setChatInput("");
    setMessages(m=>[...m,{id:Date.now(),author:user.name,color,body,kind:"chat"}]);
    await fetch(`/api/rooms/${roomCode}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"message",name:user.name,color,body})});
  }

  async function joinVoice(){
    setVoiceErr("");
    try{
      const stream=await navigator.mediaDevices.getUserMedia({audio:true});
      streamRef.current=stream; setInVoice(true); setMicOn(true);
      const ctx=new AudioContext(); const src=ctx.createMediaStreamSource(stream); const an=ctx.createAnalyser(); an.fftSize=256; src.connect(an);
      const buf=new Uint8Array(an.frequencyBinCount);
      const tick=()=>{ an.getByteFrequencyData(buf); const avg=buf.reduce((a,b)=>a+b,0)/buf.length; setLevel(Math.min(100,avg*1.6)); setSpeaking(avg>18); rafRef.current=requestAnimationFrame(tick); };
      tick();
    }catch{ setVoiceErr("Microphone permission denied or unavailable. Check browser site settings, then try again."); }
  }
  function leaveVoice(){ streamRef.current?.getTracks().forEach(t=>t.stop()); cancelAnimationFrame(rafRef.current); setInVoice(false); setSpeaking(false); setLevel(0); }
  function toggleMic(){ if(streamRef.current){ const next=!micOn; streamRef.current.getAudioTracks().forEach(t=>t.enabled=next); setMicOn(next); if(!next) setSpeaking(false); } }
  useEffect(()=>()=>{ leaveVoice(); },[]); // eslint-disable-line

  function copyText(t:string,label:string){ navigator.clipboard?.writeText(t); setCopied(label); setTimeout(()=>setCopied(""),1600); }
  function changeLang(l:string){ setLang(l); fetch(`/api/rooms/${roomCode}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({language:l})}); if(confirm(`Switch to ${l} and load starter template? Your current code will be replaced in the room.`)) setCode(starterFor(l, room?.problemId||"freestyle")); }
  function download(){ const ext=LANGS.find(l=>l.id===lang)?.ext||"txt"; const a=document.createElement("a"); a.href=URL.createObjectURL(new Blob([code],{type:"text/plain"})); a.download=`codebuddy-${roomCode}.${ext}`; a.click(); }

  const aiActions=[
    {id:"explain",label:"Explain Code",icon:FileSearch},{id:"bugs",label:"Find Bugs",icon:Bug},{id:"tests",label:"Test Cases",icon:ListChecks},
    {id:"complexity",label:"Complexity",icon:Gauge},{id:"hint",label:`Hint ${hintLevel?`(${hintLevel}/3 used)`:""}`,icon:Lightbulb},{id:"review",label:"Review Code",icon:Sparkles},{id:"interview",label:"Interview Me",icon:GraduationCap},
  ];

  if(err) return <div className="min-h-screen grid place-items-center p-6"><div className="bg-[#0D1424] border border-[#24304F] rounded-3xl p-8 max-w-md text-center"><p className="text-4xl mb-3">🔍</p><h2 className="text-xl font-bold">Room not found</h2><p className="text-slate-400 text-sm mt-2">{err}</p><button onClick={onExit} className="mt-5 bg-[#7C6CFF] px-5 py-2.5 rounded-xl font-semibold">Back to dashboard</button></div></div>;
  if(!room) return <div className="min-h-screen grid place-items-center text-slate-400"><Loader2 className="animate-spin mr-2 inline"/> Connecting to room {roomCode}…</div>;

  const invite = typeof window!=="undefined" ? `${window.location.origin}${window.location.pathname}?room=${roomCode}` : "";

  return <div className="h-screen flex flex-col bg-[#070B14] overflow-hidden">
    {/* Top bar */}
    <header className="flex items-center gap-2 px-3 sm:px-4 py-2.5 bg-[#0B1120] border-b border-[#1E2A47] flex-wrap">
      <button onClick={onExit} className="flex items-center gap-1 text-sm text-slate-300 hover:text-white bg-[#141E35] px-2.5 py-1.5 rounded-lg"><ArrowLeft size={15}/> <span className="hidden sm:inline">Dashboard</span></button>
      <div className="min-w-0">
        <p className="font-bold text-sm truncate">{room.title}</p>
        <p className="text-[11px] text-slate-400 flex items-center gap-2">
          <span className="flex items-center gap-1">{connected?<><span className="w-2 h-2 rounded-full bg-emerald-400 pulsedot"/><Wifi size={11}/> Live (synced)</>:<><span className="w-2 h-2 rounded-full bg-rose-500"/><WifiOff size={11}/> Reconnecting…</>}</span>
          {room.lastEditor && <span>· last edit by {room.lastEditor}</span>} {saved && <span className="text-emerald-400">· Saved ✓</span>}
        </p>
      </div>
      <div className="flex items-center gap-1.5 bg-[#141E35] rounded-lg px-2.5 py-1.5 ml-1">
        <span className="text-[11px] text-slate-400">ROOM</span><span className="font-mono font-bold tracking-widest text-[#A5B4FC]">{roomCode}</span>
        <button onClick={()=>copyText(roomCode,"code")} title="Copy code">{copied==="code"?<Check size={14} className="text-emerald-400"/>:<Copy size={14}/>}</button>
        <button onClick={()=>copyText(invite,"link")} className="text-[11px] bg-[#7C6CFF] text-white px-2 py-1 rounded-md ml-1">{copied==="link"?"Link copied!":"Copy invite link"}</button>
      </div>
      <div className="flex -space-x-2 ml-2">{participants.slice(0,6).map((p:any)=><span key={p.id} title={`${p.name} · line ${p.cursorLine}${p.inVoice?" · in voice":""}`} className="w-8 h-8 rounded-full border-2 border-[#0B1120] grid place-items-center text-[11px] font-bold text-white relative" style={{background:p.color}}>{p.name.slice(0,2).toUpperCase()}{p.speaking&&<span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-black"/>}</span>)}</div>
      <div className="ml-auto flex items-center gap-2">
        <select value={lang} onChange={e=>changeLang(e.target.value)} className="bg-[#141E35] text-sm rounded-lg px-2.5 py-2 outline-none border border-[#26314D]">{LANGS.map(l=><option key={l.id} value={l.id}>{l.label}</option>)}</select>
        <button onClick={download} className="hidden sm:flex items-center gap-1 bg-[#141E35] px-3 py-2 rounded-lg text-sm"><Download size={15}/> Save file</button>
        <button onClick={runCode} disabled={running} className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold px-4 py-2 rounded-lg text-sm disabled:opacity-60">{running?<Loader2 size={16} className="animate-spin"/>:<Play size={16}/>} Run Code</button>
      </div>
    </header>

    <div className="flex-1 flex min-h-0 flex-col lg:flex-row">
      {/* Problem pane */}
      <aside className="lg:w-72 shrink-0 border-b lg:border-b-0 lg:border-r border-[#1E2A47] bg-[#0A101F] p-4 overflow-y-auto scrollthin max-h-48 lg:max-h-none">
        <div className="flex items-center gap-2 flex-wrap"><h2 className="font-bold">{problem.title}</h2><span className={`text-[11px] px-2 py-0.5 rounded-full font-semibold ${problem.difficulty==="Easy"?"bg-emerald-500/15 text-emerald-300":problem.difficulty==="Medium"?"bg-amber-500/15 text-amber-300":"bg-rose-500/15 text-rose-300"}`}>{problem.difficulty}</span></div>
        <p className="text-[11px] text-slate-500 mt-1">{problem.company}</p>
        <div className="flex gap-1 mt-2 flex-wrap">{problem.tags.map(t=><span key={t} className="text-[11px] bg-[#141E35] px-2 py-0.5 rounded-full text-slate-300">{t}</span>)}</div>
        <p className="text-[13px] text-slate-300 leading-relaxed mt-3">{problem.description}</p>
        {problem.examples.map((e,i)=><div key={i} className="bg-[#0D1424] border border-[#1E2A47] rounded-xl p-3 mt-3 text-xs font-mono"><p className="text-slate-400">Input: <span className="text-slate-200">{e.input}</span></p><p className="text-slate-400 mt-1">Output: <span className="text-emerald-300">{e.output}</span></p>{e.note&&<p className="text-slate-500 mt-1 font-sans">{e.note}</p>}</div>)}
        <h3 className="text-xs font-bold text-slate-400 mt-4">CONSTRAINTS</h3><ul className="text-xs text-slate-400 list-disc ml-4 mt-1 space-y-1">{problem.constraints.map(c=><li key={c}>{c}</li>)}</ul>
        <button onClick={()=>askAI("hint")} className="mt-4 w-full flex items-center justify-center gap-2 bg-[#241E4E] text-[#C4B5FD] py-2.5 rounded-xl text-sm font-semibold"><Lightbulb size={15}/> Stuck? Get a progressive hint</button>
      </aside>

      {/* Editor area */}
      <section className="flex-1 flex flex-col min-w-0 min-h-0">
        <div className="flex items-center gap-1 px-3 pt-2 bg-[#0A101F]">
          <button onClick={()=>setTab("code")} className={`px-3.5 py-2 rounded-t-lg text-sm font-medium ${tab==="code"?"bg-[#0D1424] text-white border border-b-0 border-[#1E2A47]":"text-slate-400"}`}>⌨️ Code Editor</button>
          <button onClick={()=>setTab("board")} className={`px-3.5 py-2 rounded-t-lg text-sm font-medium ${tab==="board"?"bg-[#0D1424] text-white border border-b-0 border-[#1E2A47]":"text-slate-400"}`}>🖊️ Whiteboard</button>
          <span className="ml-auto text-[11px] text-slate-500 hidden md:block">{selectedText?`Selected ${selectedText.length} chars — AI actions will use selection`:"Tip: select code, then ask AI to explain it"} · {participants.length} online · you are on line {cursorLine}</span>
        </div>
        <div className="flex-1 min-h-[320px] border-t border-[#1E2A47]">
          {tab==="code" ? <Monaco height="100%" theme="vs-dark" language={LANGS.find(l=>l.id===lang)?.monaco||"javascript"} value={code}
            onMount={(ed:any)=>{ editorRef.current=ed; ed.onDidChangeCursorPosition((e:any)=>setCursorLine(e.position.lineNumber)); ed.onDidChangeCursorSelection(()=>{ const s=ed.getSelection(); setSelectedText(s?ed.getModel()?.getValueInRange(s)||"":""); }); }}
            onChange={(v:string|undefined)=>{ lastTypeRef.current=Date.now(); setCode(v||""); }}
            options={{fontSize:14, minimap:{enabled:false}, padding:{top:12}, scrollBeyondLastLine:false, wordWrap:"on", automaticLayout:true}} />
          : <Whiteboard strokes={Array.isArray(room.whiteboard)?room.whiteboard:[]} onChange={(s)=>{ setRoom((p:any)=>({...p,whiteboard:s})); fetch(`/api/rooms/${roomCode}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({whiteboard:s})}); }} />}
        </div>
        {/* Console */}
        <div className="border-t border-[#1E2A47] bg-[#0A0F1C]">
          <button onClick={()=>setConsoleOpen(!consoleOpen)} className="w-full flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-300"><Terminal size={14}/> OUTPUT CONSOLE {runMs>0&&<span className="text-slate-500">· {runMs} ms · sandboxed (Piston)</span>} <ChevronDown size={14} className={`ml-auto transition ${consoleOpen?"rotate-180":""}`}/></button>
          {consoleOpen && <div className="px-4 pb-3">
            <div className="flex gap-2 mb-2"><input value={stdin} onChange={e=>setStdin(e.target.value)} placeholder="stdin (optional) — e.g. 5 10" className="flex-1 bg-[#0D1424] border border-[#1E2A47] rounded-lg px-3 py-1.5 text-xs font-mono outline-none"/></div>
            <pre className="bg-[#05080F] border border-[#1E2A47] rounded-xl p-3 text-[13px] font-mono whitespace-pre-wrap max-h-40 overflow-auto scrollthin min-h-[52px]">{running?<span className="text-slate-400">Running in sandbox…</span>:<>{output&&<span className="text-emerald-200">{output}</span>}{runErr&&<span className="text-rose-300">{output?"\n":""}{runErr}</span>}{!output&&!runErr&&<span className="text-slate-500">Press ▶ Run Code — output & errors appear here. Code executes in an isolated sandbox, never on this server.</span>}</>}</pre>
          </div>}
        </div>
      </section>

      {/* Side panel */}
      <aside className="lg:w-[380px] shrink-0 border-t lg:border-t-0 lg:border-l border-[#1E2A47] bg-[#0A101F] flex flex-col min-h-[420px] lg:min-h-0">
        <div className="grid grid-cols-4 border-b border-[#1E2A47]">
          {[{id:"ai",label:"AI Mentor",icon:Bot},{id:"chat",label:"Chat",icon:MessageSquare},{id:"people",label:"People",icon:Users},{id:"voice",label:"Voice",icon:Mic}].map(t=>{ const Icon=t.icon; return <button key={t.id} onClick={()=>setSide(t.id as any)} className={`flex flex-col sm:flex-row items-center justify-center gap-1 py-2.5 text-[12px] font-semibold ${side===t.id?"text-white bg-[#141E35] border-b-2 border-[#7C6CFF]":"text-slate-400"}`}><Icon size={15}/>{t.label}</button>})}
        </div>

        {side==="ai" && <div className="flex flex-col flex-1 min-h-0">
          <div className="flex flex-wrap gap-1.5 p-3 border-b border-[#16203A]">
            {aiActions.map(a=>{ const Icon=a.icon; return <button key={a.id} disabled={!!aiBusy} onClick={()=>askAI(a.id)} className="flex items-center gap-1.5 text-[12px] bg-[#141E35] hover:bg-[#1D2A4D] border border-[#26314D] px-2.5 py-1.5 rounded-full disabled:opacity-50">{aiBusy===a.id?<Loader2 size={13} className="animate-spin"/>:<Icon size={13} className="text-[#A5B4FC]"/>}{a.label}</button>})}
          </div>
          <div className="flex-1 overflow-y-auto scrollthin p-3 space-y-3">
            {aiChat.map((m,i)=><div key={i} className={`fadeup rounded-2xl p-3 text-[13px] leading-relaxed whitespace-pre-wrap md ${m.role==="user"?"bg-[#7C6CFF] text-white ml-8":"bg-[#0D1424] border border-[#1E2A47] mr-2"}`} dangerouslySetInnerHTML={{__html: md(m.text)}} />)}
            {aiBusy && <p className="text-xs text-slate-400 flex items-center gap-2"><Loader2 size={13} className="animate-spin"/> Mentor is reading your code…</p>}
            <div ref={aiEndRef}/>
          </div>
          <form onSubmit={e=>{e.preventDefault(); const v=aiInput.trim(); if(v){ setAiInput(""); askAI("chat",v); }}} className="p-3 border-t border-[#16203A] flex gap-2">
            <input value={aiInput} onChange={e=>setAiInput(e.target.value)} placeholder="Ask: why is Map O(1)? quiz me…" className="flex-1 bg-[#0D1424] border border-[#26314D] rounded-xl px-3 py-2.5 text-sm outline-none"/>
            <button className="bg-[#7C6CFF] px-3 rounded-xl"><Send size={16}/></button>
          </form>
          <p className="px-3 pb-2 text-[10px] text-slate-500">AI suggestions are guidance, not guaranteed-correct answers. Only your current code snippet is sent for analysis.</p>
        </div>}

        {side==="chat" && <div className="flex flex-col flex-1 min-h-0">
          <div className="flex-1 overflow-y-auto scrollthin p-3 space-y-2.5">
            {messages.map((m:any)=> m.kind==="system" ? <p key={m.id} className="text-center text-[11px] text-slate-500">— {m.body} —</p> : <div key={m.id} className="flex gap-2"><span className="w-7 h-7 rounded-full grid place-items-center text-[10px] font-bold text-white shrink-0" style={{background:m.color||"#7C6CFF"}}>{String(m.author).slice(0,2).toUpperCase()}</span><div><p className="text-[11px] text-slate-400">{m.author}</p><p className="bg-[#0D1424] border border-[#1E2A47] rounded-xl px-3 py-2 text-[13px]">{m.body}</p></div></div>)}
            <div ref={chatEndRef}/>
          </div>
          <form onSubmit={e=>{e.preventDefault(); sendChat();}} className="p-3 border-t border-[#16203A] flex gap-2"><input value={chatInput} onChange={e=>setChatInput(e.target.value)} placeholder="Message your buddy…" className="flex-1 bg-[#0D1424] border border-[#26314D] rounded-xl px-3 py-2.5 text-sm outline-none"/><button className="bg-[#7C6CFF] px-3 rounded-xl"><Send size={16}/></button></form>
        </div>}

        {side==="people" && <div className="p-4 space-y-3 overflow-y-auto">
          <h3 className="font-bold text-sm">In this room ({participants.length})</h3>
          {participants.map((p:any)=><div key={p.id} className="flex items-center gap-3 bg-[#0D1424] border border-[#1E2A47] rounded-2xl p-3">
            <span className="w-10 h-10 rounded-full grid place-items-center font-bold text-white text-sm" style={{background:p.color}}>{p.name.slice(0,2).toUpperCase()}</span>
            <div className="flex-1 min-w-0"><p className="font-semibold text-sm truncate">{p.name}{p.name===user.name?" (you)":""}</p><p className="text-[11px] text-slate-400">Editing line {p.cursorLine} · {p.inVoice?(p.micOn?"🎙️ mic on":"🔇 muted"):"not in voice"}</p></div>
            <span className={`w-2.5 h-2.5 rounded-full ${p.speaking?"bg-emerald-400 pulsedot":"bg-emerald-600"}`}/>
          </div>)}
          {participants.length<=1 && <div className="bg-[#141E35] rounded-2xl p-4 text-sm text-slate-300">You're solo right now. Copy the invite link above and open it in another browser / incognito window to see real-time sync, cursors and presence.</div>}
          <button onClick={()=>copyText(invite,"link2")} className="w-full bg-[#7C6CFF] py-2.5 rounded-xl font-semibold text-sm">{copied==="link2"?"Copied!":"Copy invitation link"}</button>
        </div>}

        {side==="voice" && <div className="p-4 space-y-4 overflow-y-auto">
          <h3 className="font-bold flex items-center gap-2"><Volume2 size={17}/> Voice Chat</h3>
          <p className="text-[13px] text-slate-400 leading-relaxed">Talk while you code — perfect for interviews and teaching. Your mic level, mute and speaking status broadcast live to the room.</p>
          {voiceErr && <p className="bg-rose-500/10 border border-rose-500/30 text-rose-200 text-[13px] rounded-xl p-3">{voiceErr}</p>}
          {!inVoice ? <button onClick={joinVoice} className="w-full flex items-center justify-center gap-2 bg-emerald-500 text-black font-bold py-3 rounded-2xl"><Phone size={17}/> Join Voice Session</button>
          : <div className="space-y-3">
              <div className="bg-[#0D1424] border border-[#1E2A47] rounded-2xl p-4">
                <div className="flex items-center justify-between text-sm"><span>{micOn?"🎙️ Mic live":"🔇 Muted"}</span><span className={speaking?"text-emerald-300 font-semibold":"text-slate-500"}>{speaking?"Speaking…":"Silent"}</span></div>
                <div className="h-3 bg-[#141E35] rounded-full mt-3 overflow-hidden"><div className="h-full bg-emerald-400 transition-all" style={{width:`${micOn?level:0}%`}}/></div>
                <div className="flex items-end gap-1 h-10 mt-3">{Array.from({length:24}).map((_,i)=><span key={i} className="flex-1 bg-[#7C6CFF] rounded" style={{height:`${micOn? 20+Math.abs(Math.sin(i*1.3))*level*.7 : 12}%`, opacity:.5+((i%5)/10)}}/>)}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={toggleMic} className={`flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold text-sm ${micOn?"bg-[#141E35]":"bg-amber-500 text-black"}`}>{micOn?<MicOff size={16}/>:<Mic size={16}/>}{micOn?"Mute":"Unmute"}</button>
                <button onClick={leaveVoice} className="flex items-center justify-center gap-2 bg-rose-600 py-2.5 rounded-xl font-semibold text-sm"><PhoneOff size={16}/> Leave</button>
              </div>
            </div>}
          <div className="space-y-2"><h4 className="text-xs font-bold text-slate-400">PARTICIPANT AUDIO</h4>
            {participants.map((p:any)=><div key={p.id} className="flex items-center gap-2 text-sm bg-[#0D1424] border border-[#1E2A47] rounded-xl px-3 py-2"><span className="w-7 h-7 rounded-full grid place-items-center text-[10px] font-bold text-white" style={{background:p.color}}>{p.name.slice(0,2).toUpperCase()}</span><span className="flex-1 truncate">{p.name}</span>{p.inVoice? (p.speaking?<span className="text-emerald-300 text-xs">● speaking</span>: p.micOn?<Mic size={14} className="text-emerald-300"/>:<MicOff size={14} className="text-amber-300"/>) : <span className="text-slate-500 text-xs">not in voice</span>}</div>)}
          </div>
          <p className="text-[11px] text-slate-500">Architecture: WebRTC-style getUserMedia capture with room signalling/presence over the sync channel. Grant mic permission per browser; use headphones to avoid echo.</p>
        </div>}
      </aside>
    </div>
  </div>;
}
