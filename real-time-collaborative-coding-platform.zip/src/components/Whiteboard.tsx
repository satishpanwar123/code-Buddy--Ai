"use client";
import { useRef, useEffect, useState } from "react";
import { Pencil, Square, Circle, ArrowRight, Type, Eraser, Trash2, Minus } from "lucide-react";

type Stroke = { tool:string; color:string; width:number; points:{x:number;y:number}[]; text?:string };
export default function Whiteboard({ strokes, onChange }: { strokes: Stroke[]; onChange:(s:Stroke[])=>void }){
  const canvasRef=useRef<HTMLCanvasElement>(null);
  const [tool,setTool]=useState("pen"); const [color,setColor]=useState("#A5B4FC"); const [width,setWidth]=useState(3);
  const drawing=useRef<Stroke|null>(null); const [confirmClear,setConfirmClear]=useState(false);
  const [textVal,setTextVal]=useState("");

  function drawAll(list:Stroke[]){
    const c=canvasRef.current; if(!c) return; const ctx=c.getContext("2d"); if(!ctx) return;
    ctx.clearRect(0,0,c.width,c.height);
    // grid dots
    ctx.fillStyle="#1B2745"; for(let x=20;x<c.width;x+=28) for(let y=20;y<c.height;y+=28){ ctx.beginPath(); ctx.arc(x,y,1.2,0,7); ctx.fill(); }
    for(const s of list){
      ctx.strokeStyle=s.color; ctx.fillStyle=s.color; ctx.lineWidth=s.width; ctx.lineCap="round"; ctx.lineJoin="round";
      const p=s.points; if(!p.length) continue;
      if(s.tool==="pen"||s.tool==="line"){ ctx.beginPath(); ctx.moveTo(p[0].x,p[0].y); p.forEach(pt=>ctx.lineTo(pt.x,pt.y)); ctx.stroke(); }
      else if(s.tool==="rect"&&p.length>1){ const a=p[0],b=p[p.length-1]; ctx.strokeRect(a.x,a.y,b.x-a.x,b.y-a.y); }
      else if(s.tool==="circle"&&p.length>1){ const a=p[0],b=p[p.length-1]; ctx.beginPath(); ctx.ellipse((a.x+b.x)/2,(a.y+b.y)/2,Math.abs(b.x-a.x)/2,Math.abs(b.y-a.y)/2,0,0,7); ctx.stroke(); }
      else if(s.tool==="arrow"&&p.length>1){ const a=p[0],b=p[p.length-1]; ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke(); const ang=Math.atan2(b.y-a.y,b.x-a.x); ctx.beginPath(); ctx.moveTo(b.x,b.y); ctx.lineTo(b.x-12*Math.cos(ang-.45), b.y-12*Math.sin(ang-.45)); ctx.moveTo(b.x,b.y); ctx.lineTo(b.x-12*Math.cos(ang+.45), b.y-12*Math.sin(ang+.45)); ctx.stroke(); }
      else if(s.tool==="text"){ ctx.font="16px ui-monospace, monospace"; ctx.fillText(s.text||"", p[0].x, p[0].y); }
    }
  }
  useEffect(()=>{ drawAll(drawing.current?[...strokes,drawing.current]:strokes); },[strokes]);

  function pos(e:React.MouseEvent){ const r=canvasRef.current!.getBoundingClientRect(); return {x:(e.clientX-r.left)*(canvasRef.current!.width/r.width), y:(e.clientY-r.top)*(canvasRef.current!.height/r.height)}; }
  function down(e:React.MouseEvent){
    const p=pos(e);
    if(tool==="text"){ const val=textVal.trim()||prompt("Enter label")||""; if(val) onChange([...strokes,{tool:"text",color,width,points:[p],text:val}]); setTextVal(""); return; }
    if(tool==="eraser"){ const filtered=strokes.filter(s=>!s.points.some(pt=>Math.hypot(pt.x-p.x,pt.y-p.y)<22)); onChange(filtered); return; }
    drawing.current={tool,color,width,points:[p]};
  }
  function move(e:React.MouseEvent){ if(!drawing.current) return; drawing.current.points=[...drawing.current.points, pos(e)]; drawAll([...strokes,drawing.current]); }
  function up(){ if(drawing.current){ onChange([...strokes,drawing.current]); drawing.current=null; } }

  const tools=[{id:"pen",icon:Pencil},{id:"line",icon:Minus},{id:"rect",icon:Square},{id:"circle",icon:Circle},{id:"arrow",icon:ArrowRight},{id:"text",icon:Type},{id:"eraser",icon:Eraser}];
  const colors=["#A5B4FC","#38BDF8","#34D399","#F59E0B","#F472B6","#FFFFFF"];
  return <div className="flex flex-col h-full">
    <div className="flex flex-wrap items-center gap-2 px-3 py-2 bg-[#0D1424] border-b border-[#1E2A47]">
      {tools.map(t=>{ const Icon=t.icon; return <button key={t.id} onClick={()=>setTool(t.id)} title={t.id} className={`p-2 rounded-lg ${tool===t.id?"bg-[#7C6CFF] text-white":"bg-[#141E35] text-slate-300 hover:bg-[#1B2847]"}`}><Icon size={16}/></button>})}
      <div className="flex gap-1 ml-1">{colors.map(c=><button key={c} onClick={()=>setColor(c)} className={`w-6 h-6 rounded-full border-2 ${color===c?"border-white":"border-transparent"}`} style={{background:c}} aria-label={c}/>)}</div>
      <select value={width} onChange={e=>setWidth(+e.target.value)} className="bg-[#141E35] text-xs rounded-lg px-2 py-1.5 outline-none"><option value={2}>Thin</option><option value={3}>Medium</option><option value={5}>Thick</option><option value={8}>Bold</option></select>
      {tool==="text" && <input value={textVal} onChange={e=>setTextVal(e.target.value)} placeholder="Type then click board…" className="bg-[#141E35] text-xs rounded-lg px-2 py-1.5 outline-none w-44"/>}
      <div className="ml-auto flex items-center gap-2">
        <span className="text-[11px] text-slate-400 hidden sm:block">{strokes.length} elements · synced live</span>
        {!confirmClear ? <button onClick={()=>setConfirmClear(true)} className="flex items-center gap-1 text-xs bg-[#2A1530] text-rose-300 px-2.5 py-1.5 rounded-lg"><Trash2 size={13}/> Clear</button>
        : <span className="flex gap-1"><button onClick={()=>{onChange([]);setConfirmClear(false)}} className="text-xs bg-rose-600 text-white px-2.5 py-1.5 rounded-lg">Confirm clear</button><button onClick={()=>setConfirmClear(false)} className="text-xs bg-[#141E35] px-2.5 py-1.5 rounded-lg">Cancel</button></span>}
      </div>
    </div>
    <p className="text-[11px] text-slate-500 px-3 py-1.5 bg-[#0A101F]">Draw the recursion tree, trace pointers, sketch the DP table — everyone in the room sees it in real time.</p>
    <canvas ref={canvasRef} width={1200} height={720} onMouseDown={down} onMouseMove={move} onMouseUp={up} onMouseLeave={up} className="flex-1 w-full bg-[#0A101F] cursor-crosshair touch-none"/>
  </div>;
}
