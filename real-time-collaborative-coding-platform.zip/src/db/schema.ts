import { pgTable, text, serial, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("Student"),
  avatarColor: text("avatar_color").notNull().default("#7C6CFF"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  title: text("title").notNull(),
  language: text("language").notNull().default("javascript"),
  problemId: text("problem_id").notNull().default("two-sum"),
  problemTitle: text("problem_title").notNull().default("Two Sum"),
  codeContent: text("code_content").notNull().default(""),
  whiteboard: jsonb("whiteboard").notNull().default([]),
  ownerId: integer("owner_id"),
  ownerName: text("owner_name").notNull().default("Guest"),
  lastEditor: text("last_editor").notNull().default(""),
  version: integer("version").notNull().default(1),
  isPublic: boolean("is_public").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const participants = pgTable("participants", {
  id: serial("id").primaryKey(),
  roomCode: text("room_code").notNull(),
  userKey: text("user_key").notNull(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#38BDF8"),
  cursorLine: integer("cursor_line").notNull().default(1),
  micOn: boolean("mic_on").notNull().default(false),
  speaking: boolean("speaking").notNull().default(false),
  inVoice: boolean("in_voice").notNull().default(false),
  lastSeen: timestamp("last_seen").defaultNow().notNull(),
});

export const roomMessages = pgTable("room_messages", {
  id: serial("id").primaryKey(),
  roomCode: text("room_code").notNull(),
  author: text("author").notNull(),
  color: text("color").notNull().default("#7C6CFF"),
  body: text("body").notNull(),
  kind: text("kind").notNull().default("chat"), // chat | system
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiMessages = pgTable("ai_messages", {
  id: serial("id").primaryKey(),
  roomCode: text("room_code"),
  userEmail: text("user_email"),
  action: text("action").notNull(),
  prompt: text("prompt").notNull().default(""),
  response: text("response").notNull(),
  language: text("language").notNull().default("javascript"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const executions = pgTable("executions", {
  id: serial("id").primaryKey(),
  roomCode: text("room_code"),
  language: text("language").notNull(),
  status: text("status").notNull().default("success"),
  output: text("output").notNull().default(""),
  runtimeMs: integer("runtime_ms").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
