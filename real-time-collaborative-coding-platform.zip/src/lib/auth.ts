import crypto from "crypto";
const SECRET = process.env.AUTH_SECRET || "codebuddy-dev-secret-change-me";
export function sign(payload: Record<string, unknown>){
  const body = Buffer.from(JSON.stringify({...payload, exp: Date.now()+1000*60*60*24*14})).toString("base64url");
  const sig = crypto.createHmac("sha256", SECRET).update(body).digest("base64url");
  return body+"."+sig;
}
export function verify(token?: string|null){
  if(!token) return null;
  try{
    const [body,sig]=token.split(".");
    const exp = crypto.createHmac("sha256", SECRET).update(body).digest("base64url");
    if(sig!==exp) return null;
    const data = JSON.parse(Buffer.from(body,"base64url").toString());
    if(Date.now()>data.exp) return null;
    return data as {id:number; email:string; name:string};
  }catch{ return null; }
}
export function userFromReq(req:Request){
  const h=req.headers.get("authorization")||"";
  return verify(h.replace("Bearer ",""));
}
