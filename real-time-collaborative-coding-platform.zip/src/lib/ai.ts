import { PROBLEMS } from "./data";

function lines(code:string){ return code.split("\n"); }
function count(re:RegExp, code:string){ return (code.match(re)||[]).length; }
function fnName(code:string){
  const m = code.match(/function\s+(\w+)|def\s+(\w+)|(\w+)\s*\([^)]*\)\s*\{/);
  return (m && (m[1]||m[2]||m[3])) || "your function";
}
function analyze(code:string){
  const nested = /for[^\n]*\{[^}]*for|while[^\n]*\{[^}]*for/.test(code) || /for[^\n]*:\s*\n\s+[^\n]*for/.test(code);
  const loops = count(/\b(for|while)\b/g, code);
  const recursion = (()=>{ const n=fnName(code); return n!=="your function" && count(new RegExp(n+"\\s*\\(","g"), code)>1; })();
  const usesMap = /Map|HashMap|unordered_map|dict|\{\}/.test(code);
  const usesSort = /\.sort\(|sort\(|sorted\(/.test(code);
  const usesStack = /push|pop|stack/i.test(code);
  let time = loops===0 ? "O(1)" : nested ? "O(n²)" : loops===1 ? "O(n)" : "O(n · k)";
  if (usesSort) time = nested ? "O(n²)" : "O(n log n)";
  if (/while/.test(code) && /(lo|hi|low|high|mid)/.test(code)) time = "O(log n)";
  if (recursion) time += " (plus recursion — check branching factor)";
  const space = usesMap ? "O(n) — hash structure can hold up to n entries" : usesStack ? "O(n) worst-case stack depth" : recursion ? "O(depth) call-stack frames" : "O(1) auxiliary (excluding output)";
  return { loops, nested, recursion, usesMap, usesSort, usesStack, time, space };
}
function explainLine(l:string){
  const t=l.trim(); if(!t) return "";
  if(/^(#|\/\/)/.test(t)) return `Comment — documents intent: “${t.replace(/^(#|\/\/)\s*/,"")}”.`;
  if(/function|def |public |static |class /.test(t)) return "Declares the entry point — name it after what it returns, not how it works.";
  if(/\bfor\b/.test(t)) return "Starts a loop — each element is visited once here, so this block drives the time complexity.";
  if(/\bwhile\b/.test(t)) return "Repeats while the condition holds — make sure something inside always moves you toward termination.";
  if(/\bif\b/.test(t)) return "Decision point — this guard is where most edge-case bugs hide. Read the condition out loud.";
  if(/\breturn\b/.test(t)) return "Exits with the answer. Ask: does every code path reach a sensible return?";
  if(/Map|HashMap|unordered_map|= \{\}|= \[\]/.test(t)) return "Creates an auxiliary structure — trading memory for faster lookups.";
  if(/console\.log|print\(|cout|System\.out/.test(t)) return "Output / demo call — great for verifying behaviour with sample inputs.";
  if(/=/.test(t)) return "Assignment — updates state that later lines depend on. Watch for stale values across iterations.";
  return "Executes as part of the current block.";
}

export function runAI(action:string, code:string, opts:{language?:string; problemId?:string; prompt?:string; hintLevel?:number; selected?:string}){
  const lang = opts.language||"javascript";
  const src = (opts.selected && opts.selected.trim()) ? opts.selected : code;
  const a = analyze(code);
  const name = fnName(code);
  const problem = PROBLEMS.find(p=>p.id===opts.problemId) || PROBLEMS[0];
  const disclaimer = "\n\n> AI suggestion — verify with test cases before trusting it in an interview or production.";

  if(action==="explain"){
    const ls = lines(src).filter(l=>l.trim()).slice(0,18);
    return `**Explaining \`${name}\` (${lang}) — line by line**\n\n` + ls.map((l,i)=>`${i+1}. \`${l.trim().slice(0,72)}\`\n   ${explainLine(l)}`).join("\n") + `\n\n**In one sentence:** this code ${a.usesMap?"uses a hash structure to remember what it has seen, so it avoids re-scanning":"processes the input step-by-step"} and runs in about **${a.time}** time.${disclaimer}`;
  }
  if(action==="bugs"){
    const bugs:string[]=[];
    if(/<=\s*\w+\.length|i\s*<=\s*n\b|range\(.*len\(.*\)\s*\+\s*1/.test(code)) bugs.push("**Possible off-by-one:** a `<= length` bound usually reads one past the last valid index. Valid indices are `0 … length-1`.");
    if(/==(?!=)/.test(code) && lang==="javascript") bugs.push("**Loose equality `==`:** coerces types (`0 == ''` is true). Prefer `===` unless coercion is intentional.");
    if(/\bwhile\s*\(\s*true\s*\)|while True/.test(code) && !/break|return/.test(code)) bugs.push("**Potential infinite loop:** `while(true)` with no visible `break`/`return` will never terminate.");
    if(!/return/.test(code) && lang!=="cpp") bugs.push("**Missing return on some paths:** callers may receive `undefined`/`None` when no branch matches (e.g. no solution exists).");
    if(/\//.test(code) && !/!==\s*0|!=\s*0|if.*den|zero/i.test(code)) bugs.push("**Division without a zero-guard:** if the divisor can be 0 you'll get `Infinity` / a runtime error. Guard before dividing.");
    if(/\[0\]|\.get\(0\)|front\(\)/.test(code)) bugs.push("**First-element access:** indexing `[0]` crashes on empty input. Decide what empty input should return, then test it.");
    if(a.nested) bugs.push("**Nested loops (correctness + speed):** inner loop over the same array can pair an element with itself (`i === j`). Check that self-pairing is excluded — and consider a hash map to reach O(n).");
    if(!/length|size|len/.test(code)) bugs.push("**No length handling detected:** what happens with 0 or 1 elements? Add an early guard so the behaviour is explicit.");
    if(bugs.length===0) bugs.push("No classic bug patterns detected — good sign. Still probe: empty input, single element, duplicates, negative numbers, and the largest allowed input.");
    return `**Bug hunt for \`${name}\`** — ${bugs.length} thing(s) to check:\n\n` + bugs.map((b,i)=>`${i+1}. ${b}`).join("\n\n") + `\n\n**Try this failing case first:** empty input and an input with duplicate values — they break more DSA code than anything else.${disclaimer}`;
  }
  if(action==="tests"){
    const p=problem;
    return `**Generated test cases for ${p.title}**\n\n| # | Category | Input | Expected | Why it matters |\n|---|----------|-------|----------|----------------|\n${p.examples.map((e,i)=>`| ${i+1} | Normal | ${e.input} | ${e.output} | The documented happy path |`).join("\n")}\n| ${p.examples.length+1} | Boundary | Smallest valid input (size 1–2) | Defined by problem | Catches off-by-one at the start |\n| ${p.examples.length+2} | Edge | Empty / no-solution input | Empty / -1 / false | Most common crash in interviews |\n| ${p.examples.length+3} | Edge | All duplicates, e.g. [3,3,3] | First valid pair | Tests self-pairing & overwrite bugs |\n| ${p.examples.length+4} | Edge | Negative + large values (10⁹) | Per spec | Overflow & sign assumptions |\n| ${p.examples.length+5} | Stress | Max-size input (${p.constraints[0]||"10⁵"}) | Finishes < 1s | Exposes O(n²) solutions |\n\n**How to use:** paste them under your code as assertions, run, and only then optimise. A failing edge case teaches more than ten passing samples.${disclaimer}`;
  }
  if(action==="complexity"){
    return `**Complexity analysis — \`${name}\`**\n\n- **Time: ${a.time}**\n  ${a.nested?"Two loops are nested, so total work multiplies: n outer × n inner.":a.loops===1?"One main loop visits each element once; everything inside is O(1) on average.":a.loops>1?"Sequential loops add, they don't multiply — the dominant loop wins.":"No loops detected — constant number of operations."} ${a.usesSort?"Sorting dominates at O(n log n) for comparison sorts.":""} ${a.recursion?"Recursion detected: draw the recursion tree — branching factor ^ depth.":""}\n- **Space: ${a.space}**\n- **Detected signals:** ${a.loops} loop(s)${a.usesMap?", hash map/set":""}${a.usesSort?", sorting":""}${a.usesStack?", stack-like push/pop":""}${a.recursion?", recursion":""}.\n\n**Interview phrasing:** “We make a single pass and each lookup is average O(1), so total time is linear; we pay linear extra memory for the map, which buys us out of the quadratic brute force.”\n\n**Could it be better?** ${a.time.includes("n²")?"Yes — a hash map or two pointers (if sorted) usually cuts O(n²) to O(n).":"This is already at/near optimal for unsorted input — you must at least read every element once (Ω(n) lower bound)."}${disclaimer}`;
  }
  if(action==="hint"){
    const lvl = Math.min(opts.hintLevel||0, problem.hintLevels.length-1);
    return `**Hint ${lvl+1} of ${problem.hintLevels.length} — ${problem.title}**\n\n${problem.hintLevels[lvl]}\n\n${lvl<problem.hintLevels.length-1?"Try coding for 2–3 minutes with just this. Tap *Give Me a Hint* again only if you're still stuck — struggling a little is where the learning happens.":"That was the strongest hint — you now have the full approach. Implement it, run the samples, then ask me to review."}`;
  }
  if(action==="review"){
    return `**Code review — \`${name}\` (${lang})**\n\n**What's working**\n- ${a.usesMap?"Hash-based lookup keeps this efficient instead of brute-forcing pairs.":"Structure is straightforward and readable."}\n- Runs in about ${a.time} — ${a.time.includes("n²")?"workable for small inputs, worth optimising.":"a solid target for this problem class."}\n\n**Improve next**\n1. **Naming:** prefer names that reveal roles (\`need\`, \`seenIndex\`) over single letters outside tiny loop scopes.\n2. **Edge cases first:** add an explicit guard for empty / too-small input at the top — reviewers read top-down.\n3. **One job per function:** keep demo \`print/console.log\` calls separate from the solution so it's unit-testable.\n4. **Comment the *why*, not the *what*:** \`// remember index so we can answer in O(1)\` ages better than \`// set map\`.\n5. **Tests:** convert the sample calls into assertions so a regression fails loudly.\n\n**Readability score: ${a.nested?"7":"8"}.5 / 10** — clean core idea; polish guards and naming and this is interview-ready.${disclaimer}`;
  }
  if(action==="interview"){
    return `**Interview mode — ${problem.title}** 🎙️\n\nLet me play interviewer. Answer out loud to your buddy, then check the expected reasoning:\n\n**Q1.** Before coding — how would you brute-force this, and what's its complexity?\n*Expected:* try every pair/combination → usually O(n²) time, O(1) extra space. Say this first; interviewers want a baseline.\n\n**Q2.** What's the bottleneck, and which data structure removes it?\n*Expected:* repeated searching → hash map (O(1) lookup), or sorting + two pointers if order can change.\n\n**Q3.** Walk me through your code on \`[${problem.title==="Two Sum"?"3,2,4":"a small example"}]\`.\n*Expected:* narrate each iteration's state. This is where most marks are won.\n\n**Q4.** What breaks with duplicates / empty input / no solution?\n*Expected:* define behaviour explicitly and guard it.\n\n**Q5 (follow-up).** How does your answer change if input is sorted, streaming, or too big for memory?\n*Expected:* two pointers for sorted O(1) space; discuss trade-offs honestly.\n\nYour current code's headline: **${a.time} time, ${a.space.split("—")[0]} space.** Want me to drill one question at a time? Ask “quiz me on Q2”.`;
  }
  // chat fallback
  const q=(opts.prompt||"").toLowerCase();
  if(/complex|big o/.test(q)) return runAI("complexity",code,opts);
  if(/bug|wrong|error|fail|debug/.test(q)) return runAI("bugs",code,opts);
  if(/test/.test(q)) return runAI("tests",code,opts);
  if(/hint|stuck/.test(q)) return runAI("hint",code,opts);
  if(/review|improve|clean/.test(q)) return runAI("review",code,opts);
  if(/explain|what does|how does/.test(q)) return runAI("explain",code,opts);
  if(/quiz|interview/.test(q)) return runAI("interview",code,opts);
  return `Great question — let's anchor it to **your actual code**.\n\nYour \`${name}\` in ${lang} currently runs in about **${a.time}** with **${a.space}**. ${a.usesMap?"The hash structure is the key optimisation — it turns repeated scanning into O(1) lookups.":"The core work happens in the main loop — that's the first place to look for both bugs and optimisations."}\n\nThree productive next steps:\n1. **Explain** — I'll walk your code line by line.\n2. **Find bugs** — I'll probe edge cases (empty, duplicates, off-by-one).\n3. **Generate tests** — normal, boundary and stress cases for ${problem.title}.\n\nAsk me something specific like “why is a Map faster here?” or “what happens with [3,3]?” and I'll reason from your code, not generic theory.${disclaimer}`;
}
