export type Problem = { id:string; title:string; difficulty:string; tags:string[]; company:string; description:string; examples:{input:string;output:string;note?:string}[]; constraints:string[]; hintLevels:string[] };
export const PROBLEMS: Problem[] = [
  { id:"two-sum", title:"Two Sum", difficulty:"Easy", tags:["Array","Hash Map"], company:"Google · Amazon", description:"Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target. You may assume each input has exactly one solution, and you may not use the same element twice.", examples:[{input:"nums = [2,7,11,15], target = 9", output:"[0,1]", note:"nums[0] + nums[1] == 9"},{input:"nums = [3,2,4], target = 6", output:"[1,2]"}], constraints:["2 ≤ nums.length ≤ 10⁴","-10⁹ ≤ nums[i] ≤ 10⁹","Only one valid answer exists"], hintLevels:["Think about what you need to find for each number x: you need target − x. Have you seen it before?","A hash map can remember every value you've seen and its index in O(1) lookup time.","Iterate once. For each nums[i], check if (target − nums[i]) is in the map. If yes return both indices, otherwise store nums[i] → i."] },
  { id:"binary-search", title:"Binary Search", difficulty:"Easy", tags:["Array","Binary Search"], company:"Microsoft · Meta", description:"Given a sorted array nums and a target, return its index. If target does not exist, return -1. You must write an O(log n) algorithm.", examples:[{input:"nums = [-1,0,3,5,9,12], target = 9", output:"4"},{input:"nums = [-1,0,3,5,9,12], target = 2", output:"-1"}], constraints:["1 ≤ nums.length ≤ 10⁴","nums is sorted in ascending order"], hintLevels:["The array is sorted — you can discard half of it with every comparison.","Maintain lo and hi pointers. Compare nums[mid] with target and move the correct boundary.","mid = lo + (hi−lo)//2 avoids overflow. Loop while lo ≤ hi; if nums[mid] < target, lo = mid+1 else hi = mid−1."] },
  { id:"valid-parentheses", title:"Valid Parentheses", difficulty:"Easy", tags:["Stack","String"], company:"Amazon · Bloomberg", description:"Given a string s containing just '()[]{}', determine if it is valid: open brackets must be closed by the same type and in the correct order.", examples:[{input:'s = "()[]{}"', output:"true"},{input:'s = "([)]"', output:"false"}], constraints:["1 ≤ s.length ≤ 10⁴","s consists of parentheses only"], hintLevels:["The last opened bracket must be the first one closed. Which data structure gives you that?","Use a stack. Push every opening bracket; when you see a closing one, it must match the top.","Map each closer to its opener. At the end the stack must be empty — otherwise something was never closed."] },
  { id:"max-subarray", title:"Maximum Subarray", difficulty:"Medium", tags:["DP","Kadane's"], company:"Goldman Sachs · Adobe", description:"Given an integer array nums, find the subarray with the largest sum, and return its sum.", examples:[{input:"nums = [-2,1,-3,4,-1,2,1,-5,4]", output:"6", note:"Subarray [4,-1,2,1]"}], constraints:["1 ≤ nums.length ≤ 10⁵","-10⁴ ≤ nums[i] ≤ 10⁴"], hintLevels:["At each index you make one decision: extend the previous subarray or start fresh here.","Keep cur = max(nums[i], cur + nums[i]) and best = max(best, cur). That's Kadane's algorithm.","This is DP with O(1) space. Follow-up: can you also return the actual subarray indices?"] },
  { id:"merge-intervals", title:"Merge Intervals", difficulty:"Medium", tags:["Sorting","Intervals"], company:"Meta · Uber", description:"Given intervals [start, end], merge all overlapping intervals and return a non-overlapping list that covers the same ranges.", examples:[{input:"[[1,3],[2,6],[8,10],[15,18]]", output:"[[1,6],[8,10],[15,18]]"}], constraints:["1 ≤ intervals.length ≤ 10⁴"], hintLevels:["If intervals were sorted by start, overlapping ones would be neighbours.","Sort by start. Keep a current merged interval; extend its end with max() while overlapping.","Overlap test: next.start ≤ current.end. Otherwise push current and start a new one."] },
  { id:"lru-cache", title:"LRU Cache Design", difficulty:"Hard", tags:["Design","HashMap + DLL"], company:"Google · Amazon", description:"Design an LRU cache with get(key) and put(key, value) in O(1). When capacity is exceeded, evict the least-recently-used key.", examples:[{input:"put(1,1), put(2,2), get(1), put(3,3)", output:"get(1)=1, key 2 evicted"}], constraints:["1 ≤ capacity ≤ 3000","Up to 2×10⁵ operations"], hintLevels:["You need O(1) lookup AND O(1) reordering. One structure rarely gives both.","HashMap for lookup + doubly-linked list for recency order. Most-recent at head, LRU at tail.","On get/put, move node to head. On overflow, remove tail node and delete it from the map."] },
  { id:"freestyle", title:"Freestyle Playground", difficulty:"Open", tags:["Sandbox"], company:"Your team", description:"An open canvas for pair programming, experiments, code reviews and teaching. No problem statement — bring your own idea and build it live with your buddy.", examples:[{input:"Anything you type", output:"Run it and see"}], constraints:["No constraints — just code"], hintLevels:["Start by writing what 'done' looks like: input → output in one comment.","Break the problem into the smallest runnable step and run it early.","Ask the AI Mentor to review your approach before you optimise."] },
];

export const STARTERS: Record<string, Record<string,string>> = {
  javascript: {
    "two-sum": `// Two Sum — return indices of the two numbers that add up to target
function twoSum(nums, target) {
  const seen = new Map(); // value -> index
  for (let i = 0; i < nums.length; i++) {
    const need = target - nums[i];
    if (seen.has(need)) return [seen.get(need), i];
    seen.set(nums[i], i);
  }
  return [];
}

console.log(twoSum([2, 7, 11, 15], 9)); // [0, 1]
console.log(twoSum([3, 2, 4], 6));       // [1, 2]
console.log(twoSum([3, 3], 6));          // [0, 1]
`,
    "binary-search": `// Binary Search — O(log n)
function search(nums, target) {
  let lo = 0, hi = nums.length - 1;
  while (lo <= hi) {
    const mid = lo + Math.floor((hi - lo) / 2);
    if (nums[mid] === target) return mid;
    if (nums[mid] < target) lo = mid + 1;
    else hi = mid - 1;
  }
  return -1;
}
console.log(search([-1,0,3,5,9,12], 9)); // 4
console.log(search([-1,0,3,5,9,12], 2)); // -1
`,
    default: `// CodeBuddy-AI playground — write, run, share in real time
function greet(name) {
  return "Hello, " + name + "! Let's code together.";
}
console.log(greet("Buddy"));
for (let i = 1; i <= 5; i++) console.log("Step", i, "→", i * i);
`,
  },
  python: {
    "two-sum": `# Two Sum — return indices of the two numbers that add up to target
def two_sum(nums, target):
    seen = {}  # value -> index
    for i, x in enumerate(nums):
        need = target - x
        if need in seen:
            return [seen[need], i]
        seen[x] = i
    return []

print(two_sum([2, 7, 11, 15], 9))  # [0, 1]
print(two_sum([3, 2, 4], 6))       # [1, 2]
print(two_sum([3, 3], 6))          # [0, 1]
`,
    default: `# CodeBuddy-AI playground
def greet(name):
    return f"Hello, {name}! Let's code together."

print(greet("Buddy"))
for i in range(1, 6):
    print("Step", i, "->", i * i)
`,
  },
  cpp: {
    default: `#include <bits/stdc++.h>
using namespace std;

// Two Sum with unordered_map — O(n)
vector<int> twoSum(vector<int>& nums, int target) {
    unordered_map<int,int> seen;
    for (int i = 0; i < (int)nums.size(); i++) {
        int need = target - nums[i];
        if (seen.count(need)) return {seen[need], i};
        seen[nums[i]] = i;
    }
    return {};
}

int main() {
    vector<int> nums = {2, 7, 11, 15};
    auto ans = twoSum(nums, 9);
    cout << "[" << ans[0] << ", " << ans[1] << "]" << endl;
    return 0;
}
`,
  },
  java: {
    default: `import java.util.*;

public class Main {
    // Two Sum with HashMap — O(n)
    static int[] twoSum(int[] nums, int target) {
        Map<Integer, Integer> seen = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            int need = target - nums[i];
            if (seen.containsKey(need)) return new int[]{seen.get(need), i};
            seen.put(nums[i], i);
        }
        return new int[]{};
    }
    public static void main(String[] args) {
        int[] ans = twoSum(new int[]{2,7,11,15}, 9);
        System.out.println(Arrays.toString(ans));
    }
}
`,
  },
};
export function starterFor(lang:string, problemId:string){ const l=STARTERS[lang]||STARTERS.javascript; return l[problemId]||l.default; }
export const LANGS=[{id:"javascript",label:"JavaScript",ext:"js",monaco:"javascript"},{id:"python",label:"Python",ext:"py",monaco:"python"},{id:"cpp",label:"C++",ext:"cpp",monaco:"cpp"},{id:"java",label:"Java",ext:"java",monaco:"java"},{id:"typescript",label:"TypeScript",ext:"ts",monaco:"typescript"}];
