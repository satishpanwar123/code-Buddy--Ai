import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
export const metadata: Metadata = { title: "CodeBuddy-AI — Code Together. Learn Faster.", description: "Real-time collaborative coding with AI mentoring, voice, whiteboard and sandboxed execution." };
export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
