import { NextResponse } from "next/server";
import { db } from "@/db";
import { executions } from "@/db/schema";
export const dynamic="force-dynamic";

const MAP: Record<string,{language:string; version:string; file:string}> = {
  javascript:{language:"javascript", version:"18.15.0", file:"main.js"},
  typescript:{language:"typescript", version:"5.0.3", file:"main.ts"},
  python:{language:"python", version:"3.10.0", file:"main.py"},
  cpp:{language:"c++", version:"10.2.0", file:"main.cpp"},
  java:{language:"java", version:"15.0.2", file:"Main.java"},
};

export async function POST(req:Request){
  const b=await req.json().catch(()=>({}));
  const lang=String(b.language||"javascript"); const cfg=MAP[lang]||MAP.javascript;
  const source=String(b.code||""); const stdin=String(b.stdin||"");
  if(!source.trim()) return NextResponse.json({error:"No code to run"},{status:400});
  if(source.length>40000) return NextResponse.json({error:"Code too large"},{status:413});
  const started=Date.now();
  try{
    const ctrl=new AbortController(); const t=setTimeout(()=>ctrl.abort(), 12000);
    const res=await fetch("https://emkc.org/api/v2/piston/execute", { method:"POST", signal:ctrl.signal, headers:{"Content-Type":"application/json"}, body: JSON.stringify({language:cfg.language, version:cfg.version, files:[{name:cfg.file, content:source}], stdin, compile_timeout:8000, run_timeout:5000}) });
    clearTimeout(t);
    if(!res.ok) throw new Error("sandbox "+res.status);
    const data:any=await res.json();
    const compile=data.compile||{}; const run=data.run||{};
    const stderr=[compile.stderr, run.stderr].filter(Boolean).join("\n");
    const stdout=run.stdout||"";
    const status = stderr && !stdout ? "error" : "success";
    const ms=Date.now()-started;
    await db.insert(executions).values({roomCode:b.roomCode||null, language:lang, status, output:(stdout||stderr).slice(0,4000), runtimeMs:ms}).catch(()=>null);
    return NextResponse.json({stdout, stderr, exitCode: run.code ?? compile.code ?? 0, runtimeMs:ms, engine:"Piston sandbox (isolated — code never runs on the app server)"});
  }catch(e:any){
    // Signal client to use local JS fallback
    return NextResponse.json({stdout:"", stderr:"", fallback:true, error:"Remote sandbox unreachable ("+(e?.message||"network")+"). "+(lang==="javascript"?"Falling back to in-browser execution.":"Check connection and retry."), runtimeMs:Date.now()-started});
  }
}
