import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { sign, userFromReq } from "@/lib/auth";
export const dynamic="force-dynamic";
const COLORS=["#7C6CFF","#38BDF8","#34D399","#F59E0B","#F472B6","#22D3EE"];

export async function GET(req:Request){
  const u=userFromReq(req); if(!u) return NextResponse.json({user:null});
  const rows=await db.select().from(users).where(eq(users.id,u.id)).limit(1);
  if(!rows[0]) return NextResponse.json({user:null});
  const {passwordHash:_,...safe}=rows[0]; return NextResponse.json({user:safe});
}
export async function POST(req:Request){
  const b=await req.json().catch(()=>({}));
  const mode=b.mode; const email=String(b.email||"").trim().toLowerCase(); const password=String(b.password||"");
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({error:"Enter a valid email address"},{status:400});
  if(password.length<6) return NextResponse.json({error:"Password must be at least 6 characters"},{status:400});
  if(mode==="register"){
    const name=String(b.name||"").trim(); if(name.length<2) return NextResponse.json({error:"Enter your name"},{status:400});
    const existing=await db.select().from(users).where(eq(users.email,email)).limit(1);
    if(existing[0]) return NextResponse.json({error:"Account already exists — sign in instead"},{status:409});
    const hash=await bcrypt.hash(password,10);
    const [u]=await db.insert(users).values({name,email,passwordHash:hash,role:String(b.role||"Student"),avatarColor:COLORS[Math.floor(Math.random()*COLORS.length)]}).returning();
    const {passwordHash:_,...safe}=u; return NextResponse.json({user:safe, token:sign({id:u.id,email:u.email,name:u.name})});
  }
  const rows=await db.select().from(users).where(eq(users.email,email)).limit(1);
  const u=rows[0];
  if(!u || !(await bcrypt.compare(password,u.passwordHash))) return NextResponse.json({error:"Invalid email or password"},{status:401});
  const {passwordHash:_,...safe}=u; return NextResponse.json({user:safe, token:sign({id:u.id,email:u.email,name:u.name})});
}
