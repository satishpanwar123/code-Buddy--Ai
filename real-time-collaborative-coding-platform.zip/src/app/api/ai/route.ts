import { NextResponse } from "next/server";
import { db } from "@/db";
import { aiMessages } from "@/db/schema";
import { runAI } from "@/lib/ai";
import { userFromReq } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";
export const dynamic="force-dynamic";

export async function GET(req:Request){
  const u=userFromReq(req);
  const rows = u?.email ? await db.select().from(aiMessages).where(eq(aiMessages.userEmail,u.email)).orderBy(desc(aiMessages.id)).limit(30) : await db.select().from(aiMessages).orderBy(desc(aiMessages.id)).limit(20);
  return NextResponse.json({history:rows});
}
export async function POST(req:Request){
  const b=await req.json().catch(()=>({}));
  const code=String(b.code||"");
  if(code.length>20000) return NextResponse.json({error:"Code snippet too large for AI analysis (max 20k chars)"},{status:413});
  if(!code.trim()) return NextResponse.json({error:"Write some code first, then ask the AI Mentor"},{status:400});
  const action=String(b.action||"chat");
  // If a real LLM key is configured, we still use local engine for deterministic, key-free operation in sandbox.
  const response=runAI(action, code, {language:b.language, problemId:b.problemId, prompt:b.prompt, hintLevel:Number(b.hintLevel||0), selected:b.selected});
  const u=userFromReq(req);
  const [saved]=await db.insert(aiMessages).values({roomCode:b.roomCode||null, userEmail:u?.email||b.email||null, action, prompt:String(b.prompt||action).slice(0,500), response, language:String(b.language||"javascript")}).returning();
  return NextResponse.json({response, id:saved.id, action});
}
