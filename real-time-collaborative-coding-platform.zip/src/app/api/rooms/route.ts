import { NextResponse } from "next/server";
import { db } from "@/db";
import { rooms, roomMessages, aiMessages, executions, participants } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { starterFor, PROBLEMS } from "@/lib/data";
import { userFromReq } from "@/lib/auth";
export const dynamic="force-dynamic";
function genCode(){ const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; return Array.from({length:6},()=>c[Math.floor(Math.random()*c.length)]).join(""); }

export async function GET(req:Request){
  const url=new URL(req.url);
  if(url.searchParams.get("stats")){
    const all=await db.select().from(rooms);
    const ai=await db.select().from(aiMessages);
    const ex=await db.select().from(executions);
    return NextResponse.json({ rooms: all.length, aiSessions: ai.length, executions: ex.length });
  }
  const list=await db.select().from(rooms).orderBy(desc(rooms.updatedAt)).limit(30);
  // attach participant counts
  const parts=await db.select().from(participants);
  const cutoff=Date.now()-25000;
  const withCounts=list.map(r=>({...r, liveCount: parts.filter(p=>p.roomCode===r.code && new Date(p.lastSeen).getTime()>cutoff).length}));
  return NextResponse.json({rooms:withCounts});
}
export async function POST(req:Request){
  const b=await req.json().catch(()=>({}));
  const user=userFromReq(req);
  const problemId=String(b.problemId||"two-sum");
  const problem=PROBLEMS.find(p=>p.id===problemId)||PROBLEMS[0];
  const language=String(b.language||"javascript");
  let code=genCode();
  for(let i=0;i<5;i++){ const ex=await db.select().from(rooms).where(eq(rooms.code,code)).limit(1); if(!ex[0]) break; code=genCode(); }
  const [room]=await db.insert(rooms).values({
    code, title: String(b.title||`${problem.title} Session`).slice(0,90), language, problemId, problemTitle: problem.title,
    codeContent: starterFor(language, problemId), ownerId: user?.id||null, ownerName: user?.name||String(b.ownerName||"Guest Coder"), whiteboard: []
  }).returning();
  await db.insert(roomMessages).values({roomCode:code, author:"CodeBuddy", color:"#7C6CFF", kind:"system", body:`Room created for ${problem.title}. Share code ${code} to invite your buddy.`});
  return NextResponse.json({room});
}
