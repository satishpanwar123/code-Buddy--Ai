import { NextResponse } from "next/server";
import { db } from "@/db";
import { rooms, participants, roomMessages, aiMessages } from "@/db/schema";
import { eq, asc, desc, and } from "drizzle-orm";
export const dynamic="force-dynamic";

async function getRoom(code:string){ const r=await db.select().from(rooms).where(eq(rooms.code,code.toUpperCase())).limit(1); return r[0]||null; }

export async function GET(_req:Request, ctx:{params:Promise<{code:string}>}){
  const {code}=await ctx.params;
  const room=await getRoom(code); if(!room) return NextResponse.json({error:"Room not found — check the code and try again"},{status:404});
  const parts=await db.select().from(participants).where(eq(participants.roomCode,room.code));
  const cutoff=Date.now()-25000;
  const live=parts.filter(p=>new Date(p.lastSeen).getTime()>cutoff);
  const msgs=await db.select().from(roomMessages).where(eq(roomMessages.roomCode,room.code)).orderBy(asc(roomMessages.id)).limit(80);
  const ai=await db.select().from(aiMessages).where(eq(aiMessages.roomCode,room.code)).orderBy(desc(aiMessages.id)).limit(20);
  return NextResponse.json({room, participants:live, messages:msgs, aiHistory:ai.reverse()});
}

export async function POST(req:Request, ctx:{params:Promise<{code:string}>}){
  const {code}=await ctx.params; const room=await getRoom(code); if(!room) return NextResponse.json({error:"Room not found"},{status:404});
  const b=await req.json().catch(()=>({}));
  // heartbeat / presence
  if(b.type==="heartbeat"){
    const userKey=String(b.userKey||"anon");
    const existing=await db.select().from(participants).where(and(eq(participants.roomCode,room.code), eq(participants.userKey,userKey))).limit(1);
    const vals={ roomCode:room.code, userKey, name:String(b.name||"Guest").slice(0,40), color:String(b.color||"#7C6CFF"), cursorLine:Number(b.cursorLine||1), micOn:!!b.micOn, speaking:!!b.speaking, inVoice:!!b.inVoice, lastSeen:new Date() };
    if(existing[0]) await db.update(participants).set(vals).where(eq(participants.id,existing[0].id));
    else { await db.insert(participants).values(vals); await db.insert(roomMessages).values({roomCode:room.code, author:"CodeBuddy", color:"#38BDF8", kind:"system", body:`${vals.name} joined the room 👋`}); }
    return NextResponse.json({ok:true});
  }
  if(b.type==="message"){
    const [m]=await db.insert(roomMessages).values({roomCode:room.code, author:String(b.name||"Guest").slice(0,40), color:String(b.color||"#7C6CFF"), body:String(b.body||"").slice(0,600)}).returning();
    return NextResponse.json({message:m});
  }
  // code / fields sync
  const patch: Record<string,unknown>={updatedAt:new Date()};
  if(typeof b.codeContent==="string"){ if(b.codeContent.length>60000) return NextResponse.json({error:"Code too large"},{status:413}); patch.codeContent=b.codeContent; patch.lastEditor=String(b.editor||""); patch.version=(room.version||1)+1; }
  if(typeof b.language==="string") patch.language=b.language;
  if(b.whiteboard!==undefined) patch.whiteboard=b.whiteboard;
  if(typeof b.title==="string") patch.title=b.title.slice(0,90);
  const [updated]=await db.update(rooms).set(patch).where(eq(rooms.id,room.id)).returning();
  return NextResponse.json({room:updated});
}
